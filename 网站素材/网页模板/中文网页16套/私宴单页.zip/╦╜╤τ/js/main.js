$('.title-tab li').click(function(){
		var index1 = $(this).index();
		$('.title-tab li').removeClass('active');
		$(this).addClass('active');
		switch (index1) {
            case 0:$('.tab-con').hide();$('.tab-con1').show(); break;
			case 1:$('.tab-con').hide();$('.tab-con2').show(); break;
			case 2:$('.tab-con').hide();$('.tab-con3').show(); break;
			case 3:$('.tab-con').hide();$('.tab-con4').show(); break;
			case 4:$('.tab-con').hide();$('.tab-con5').show(); break;
			case 5:$('.tab-con').hide();$('.tab-con6').show(); break;
        }
	});
var mySwiper1 = new Swiper('.swiper-container1',{
    slidesPerView: 2,
});
var mySwiper2 = new Swiper('.swiper-container2',{
    slidesPerView: 2,
});
var mySwiper3 = new Swiper('.swiper-container3',{
    slidesPerView: 2,
});
var mySwiper4 = new Swiper('.swiper-container4',{
    slidesPerView: 2,
});
var mySwiper5 = new Swiper('.swiper-container5',{
    slidesPerView: 2,
});
var mySwiper6 = new Swiper('.swiper-container6',{
    slidesPerView: 2,
});

$('.arrow-left').click(function(e){
	e.preventDefault();
	$('.arrow-left').css({background:"#ddd",color:"#333"});
	$('.arrow-right').css({background:"#eb6100",color:"#fff"});
	mySwiper1.swipePrev();
	mySwiper2.swipePrev();
	mySwiper3.swipePrev();
	mySwiper4.swipePrev();
	mySwiper5.swipePrev();
	mySwiper6.swipePrev();
});
$('.arrow-right').click(function(e){
	e.preventDefault();
	$('.arrow-right').css({background:"#ddd",color:"#333"});
	$('.arrow-left').css({background:"#eb6100",color:"#fff"});
	mySwiper1.swipeNext();
	mySwiper2.swipeNext();
	mySwiper3.swipeNext();
	mySwiper4.swipeNext();
	mySwiper5.swipeNext();
	mySwiper6.swipeNext();
});