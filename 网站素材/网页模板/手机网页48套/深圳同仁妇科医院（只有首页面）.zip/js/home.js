﻿// JavaScript Document
//Ning zhenBang by 2011.1.26
function G(id){return document.getElementById(id);}

/**
 *@id 菜单选项。这里是一个UL对象id
 *@useId,true|false 是否有对象模块切换
 */
function getMenus_Item4(id,useId){
	var g=null; var band=null;
	try{
		var menus=G(id).getElementsByTagName('li');
		g=menus[0];//默认第一个被选
		g.name=0;//设定默认参数
		band=G(id+"_"+'0');//默认第一个显示
		for(i=0;i<menus.length;i++){
			menus[i].name=i;
			menus[i].onmouseover=function(){			  
			  /*切换相应模块*/
			  try{
			   var ov_var=useId?parseInt(parseInt(this.name)+1):'';
			   var ot_var=useId?parseInt(parseInt(g.name)+1):'';
			   //alert(ot_var);			
			   this.className='ov'+ov_var;//鼠标移到菜单效果  
			   G(id+"_"+this.name).style.display='';//对应模块显示方式
			  if(g!=this){
				  g.className='ot'+ot_var;//鼠标移出菜单效果
				  band.style.display='none';//对应模块显示方式
				  g=this; band=G(id+"_"+this.name);
				  }	
			  }catch(err){
				  if(g!=this){g.className='ot'+ot_var;g=this;}				 			  
				}
			}
		}
   }catch(err){}
}

function getMenus_Item2(id,useId){
	var g=null; var band=null;
	try{
		var menus=G(id).getElementsByTagName('li');
		g=menus[0];//默认第一个被选
		g.name=0;//设定默认参数
		band=G(id+"_"+'0');//默认第一个显示
		for(i=0;i<menus.length;i++){
			menus[i].name=i;
			menus[i].onmouseover=function(){			  
			  /*切换相应模块*/
			  try{
			   var ov_var=useId?parseInt(parseInt(this.name)+1):'';
			   var ot_var=useId?parseInt(parseInt(g.name)+1):'';
			   //alert(ot_var);			
			   this.className='over'+ov_var;//鼠标移到菜单效果  
			   G(id+"_"+this.name).style.display='';//对应模块显示方式
			  if(g!=this){
				  g.className='ot'+ot_var;//鼠标移出菜单效果
				  band.style.display='none';//对应模块显示方式
				  g=this; band=G(id+"_"+this.name);
				  }	
			  }catch(err){
				  if(g!=this){g.className='ot'+ot_var;g=this;}				 			  
				}
			}
		}
   }catch(err){}
}


function getMenus_Item3(id,useId){
	var g=null; var band=null;
	try{
		var menus=G(id).getElementsByTagName('div');
		g=menus[0];//默认第一个被选
		g.name=0;//设定默认参数
		band=G(id+"_"+'0');//默认第一个显示
		for(i=0;i<menus.length;i++){
			menus[i].name=i;
			menus[i].onmouseover=function(){	
			//menus[i].onclick=function(){			  
			  /*切换相应模块*/
			  try{
			   var ov_var=useId?parseInt(parseInt(this.name)+1):'';
			   var ot_var=useId?parseInt(parseInt(g.name)+1):'';
			   //alert(ot_var);			
			   this.className='ov' + useId +ov_var;//鼠标移到菜单效果
			   //alert(this.className);
			   G(id+"_"+this.name).style.display='';//对应模块显示方式
			  if(g!=this){
				  g.className='ot' + useId +ot_var;//鼠标移出菜单效果
				  band.style.display='none';//对应模块显示方式
				  g=this; band=G(id+"_"+this.name);
				  }	
			  }catch(err){
				  if(g!=this){g.className='ot' + useId +ot_var;g=this;}				 			  
				}
			}
		}
   }catch(err){}
}

