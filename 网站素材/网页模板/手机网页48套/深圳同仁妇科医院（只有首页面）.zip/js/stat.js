
if(document.domain.indexOf("3g.23462210.com")==0)
        { 
document.writeln("<script type=\"text\/javascript\" src=\"../js.tongji.linezing.com/3502517/tongji.js\"><\/script><noscript><a href=\"../www.linezing.com/default.htm\"><img src=\"../img.tongji.linezing.com/3502517/tongji.gif\"\/><\/a><\/noscript>");
 //alert("ͳ�ƴ���");

}
if(document.domain.indexOf("m.23462210.com")==0){
document.writeln("<script type=\"text\/javascript\" src=\"../js.tongji.linezing.com/3502515/tongji.js\"><\/script><noscript><a href=\"../www.linezing.com/default.htm\"><img src=\"../img.tongji.linezing.com/3502515/tongji.gif\"\/><\/a><\/noscript>");
        }
		
if(document.domain.indexOf("m.trfkyy.com")==0){
document.writeln("<script type=\"text\/javascript\" src=\"../js.tongji.linezing.com/3502514/tongji.js\"><\/script><noscript><a href=\"../www.linezing.com/default.htm\"><img src=\"../img.tongji.linezing.com/3502514/tongji.gif\"\/><\/a><\/noscript>");
        }		
if(document.domain.indexOf("3g.trfkyy.com")==0){
document.writeln("<script type=\"text\/javascript\" src=\"../js.tongji.linezing.com/3502513/tongji.js\"><\/script><noscript><a href=\"../www.linezing.com/default.htm\"><img src=\"../img.tongji.linezing.com/3502513/tongji.gif\"\/><\/a><\/noscript>");
        }	