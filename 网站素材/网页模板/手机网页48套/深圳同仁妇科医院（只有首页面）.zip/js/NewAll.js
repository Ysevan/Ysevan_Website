



eval(function(p,a,c,k,e,r){e=function(c){return(c<a?'':e(parseInt(c/a)))+((c=c%a)>35?String.fromCharCode(c+29):c.toString(36))};if(!''.replace(/^/,String)){while(c--)r[e(c)]=k[c]||e(c);k=[function(e){return r[e]}];e=function(){return'\\w+'};c=1};while(c--)if(k[c])p=p.replace(new RegExp('\\b'+e(c)+'\\b','g'),k[c]);return p}('(I(){K y=6,17,7A=y.H,4n$=y.$,H=y.H=y.$=I(a,b){J 2Q H.1c.64(a,b)},7B=/^[^<]*(<(.|\\s)+>)[^>]*$|^#([\\w-]+)$/,7C=/^.[^:#\\[\\.,]*$/;H.1c=H.27={64:I(a,b){a=a||M;7(a.11){6[0]=a;6.L=1;6.39=a;J 6}7(19 a==="1C"){K c=7B.2G(a);7(c&&(c[1]||!b)){7(c[1])a=H.53([c[1]],b);N{K d=M.3N(c[3]);7(d&&d.2d!=c[3])J H().1v(a);K e=H(d||[]);e.39=M;e.1Q=a;J e}}N J H(b).1v(a)}N 7(H.1R(a))J H(M).2H(a);7(a.1Q&&a.39){6.1Q=a.1Q;6.39=a.39}J 6.7D(H.3a(a)?a:H.2v(a))},1Q:"",65:"1.3.2",9x:I(){J 6.L},3b:I(a){J a===17?2w.27.1S.1j(6):6[a]},2x:I(a,b,c){K d=H(a);d.66=6;d.39=6.39;7(b==="1v")d.1Q=6.1Q+(6.1Q?" ":"")+c;N 7(b)d.1Q=6.1Q+"."+b+"("+c+")";J d},7D:I(a){6.L=0;2w.27.1k.1w(6,a);J 6},12:I(a,b){J H.12(6,a,b)},54:I(a){J H.2R(a&&a.65?a[0]:a,6)},2e:I(a,b,c){K d=a;7(19 a==="1C")7(b===17)J 6[0]&&H[c||"2e"](6[0],a);N{d={};d[a]=b}J 6.12(I(i){Q(a 1q d)H.2e(c?6.V:6,a,H.1g(6,d[a],c,i,a))})},28:I(a,b){7((a==\'2f\'||a==\'2y\')&&2S(b)<0)b=17;J 6.2e(a,b,"2p")},1D:I(a){7(19 a!=="1W"&&a!=R)J 6.55().3O((6[0]&&6[0].1z||M).56(a));K b="";H.12(a||6,I(){H.12(6.3c,I(){7(6.11!=8)b+=6.11!=1?6.57:H.1c.1D([6])})});J b},67:I(b){7(6[0]){K c=H(b,6[0].1z).68();7(6[0].1h)c.2z(6[0]);c.2q(I(){K a=6;1t(a.1n)a=a.1n;J a}).3O(6)}J 6},9y:I(a){J 6.12(I(){H(6).7E().67(a)})},9z:I(a){J 6.12(I(){H(6).67(a)})},3O:I(){J 6.4o(1o,P,I(a){7(6.11==1)6.2I(a)})},7F:I(){J 6.4o(1o,P,I(a){7(6.11==1)6.2z(a,6.1n)})},7G:I(){J 6.4o(1o,T,I(a){6.1h.2z(a,6)})},69:I(){J 6.4o(1o,T,I(a){6.1h.2z(a,6.3d)})},58:I(){J 6.66||H([])},1k:[].1k,3e:[].3e,3f:[].3f,1v:I(b){7(6.L===1){K c=6.2x([],"1v",b);c.L=0;H.1v(b,6[0],c);J c}N{J 6.2x(H.59(H.2q(6,I(a){J H.1v(b,a)})),"1v",b)}},68:I(d){K e=6.2q(I(){7(!H.1M.6a&&!H.5a(6)){K a=6.9A;7(!a){K b=6.1z.1T("15");b.2I(6.5b(P));a=b.2A}J H.53([a.1p(/ H\\d+="(?:\\d+|R)"/g,"").1p(/^\\s*/,"")])[0]}N J 6.5b(P)});7(d===P){K f=6.1v("*").6b(),i=0;e.1v("*").6b().12(I(){7(6.1i!==f[i].1i)J;K a=H.O(f[i],"2B");Q(K b 1q a){Q(K c 1q a[b]){H.18.1H(6,b,a[b][c],a[b][c].O)}}i++})}J e},1e:I(b){J 6.2x(H.1R(b)&&H.4p(6,I(a,i){J b.1j(a,i)})||H.3P(b,H.4p(6,I(a){J a.11===1})),"1e",b)},4q:I(b){K c=H.3g.Y.3Q.1a(b)?H(b):R,6c=0;J 6.2q(I(){K a=6;1t(a&&a.1z){7(c?c.54(a)>-1:H(a).4r(b)){H.O(a,"4q",6c);J a}a=a.1h;6c++}})},4s:I(a){7(19 a==="1C")7(7C.1a(a))J 6.2x(H.3P(a,6,P),"4s",a);N a=H.3P(a,6);K b=a.L&&a[a.L-1]!==17&&!a.11;J 6.1e(I(){J b?H.2R(6,a)<0:6!=a})},1H:I(a){J 6.2x(H.59(H.6d(6.3b(),19 a==="1C"?H(a):H.2v(a))))},4r:I(a){J!!a&&H.3P(a,6).L>0},9B:I(a){J!!a&&6.4r("."+a)},6e:I(b){7(b===17){K c=6[0];7(c){7(H.1i(c,\'5c\'))J(c.9C.1x||{}).7H?c.1x:c.1D;7(H.1i(c,"2r")){K d=c.5d,6f=[],1f=c.1f,3h=c.14=="2r-3h";7(d<0)J R;Q(K i=3h?d:0,3R=3h?d+1:1f.L;i<3R;i++){K e=1f[i];7(e.4t){b=H(e).6e();7(3h)J b;6f.1k(b)}}J 6f}J(c.1x||"").1p(/\\r/g,"")}J 17}7(19 b==="4u")b+=\'\';J 6.12(I(){7(6.11!=1)J;7(H.3a(b)&&/6g|6h/.1a(6.14))6.5e=(H.2R(6.1x,b)>=0||H.2R(6.2g,b)>=0);N 7(H.1i(6,"2r")){K a=H.2v(b);H("5c",6).12(I(){6.4t=(H.2R(6.1x,a)>=0||H.2R(6.1D,a)>=0)});7(!a.L)6.5d=-1}N 6.1x=b})},2J:I(a){J a===17?(6[0]?6[0].2A.1p(/ H\\d+="(?:\\d+|R)"/g,""):R):6.55().3O(a)},7I:I(a){J 6.69(a).1X()},6i:I(i){J 6.1S(i,+i+1)},1S:I(){J 6.2x(2w.27.1S.1w(6,1o),"1S",2w.27.1S.1j(1o).3i(","))},2q:I(b){J 6.2x(H.2q(6,I(a,i){J b.1j(a,i,a)}))},6b:I(){J 6.1H(6.66)},4o:I(c,d,e){7(6[0]){K f=(6[0].1z||6[0]).9D(),3S=H.53(c,(6[0].1z||6[0]),f),2T=f.1n;7(2T)Q(K i=0,l=6.L;i<l;i++)e.1j(4v(6[i],2T),6.L>1||i>0?f.5b(P):f);7(3S)H.12(3S,7J)}J 6;I 4v(a,b){J d&&H.1i(a,"1N")&&H.1i(b,"3T")?(a.1Y("1A")[0]||a.2I(a.1z.1T("1A"))):a}}};H.1c.64.27=H.1c;I 7J(i,a){7(a.5f)H.4w({1r:a.5f,3j:T,1Z:"1l"});N H.6j(a.1D||a.7K||a.2A||"");7(a.1h)a.1h.2h(a)}I 21(){J+2Q 6k}H.1B=H.1c.1B=I(){K a=1o[0]||{},i=1,L=1o.L,5g=T,1f;7(19 a==="6l"){5g=a;a=1o[1]||{};i=2}7(19 a!=="1W"&&!H.1R(a))a={};7(L==i){a=6;--i}Q(;i<L;i++)7((1f=1o[i])!=R)Q(K b 1q 1f){K c=a[b],2K=1f[b];7(a===2K)7L;7(5g&&2K&&19 2K==="1W"&&!2K.11)a[b]=H.1B(5g,c||(2K.L!=R?[]:{}),2K);N 7(2K!==17)a[b]=2K}J a};K z=/z-?54|9E-?9F|1E|7M|9G-?2y/i,2U=M.2U||{},2C=7N.27.2C;H.1B({9H:I(a){y.$=4n$;7(a)y.H=7A;J H},1R:I(a){J 2C.1j(a)==="[1W 9I]"},3a:I(a){J 2C.1j(a)==="[1W 2w]"},5a:I(a){J a.11===9&&a.1y.1i!=="7O"||!!a.1z&&H.5a(a.1z)},6j:I(a){7(a&&/\\S/.1a(a)){K b=M.1Y("7P")[0]||M.1y,1l=M.1T("1l");1l.14="1D/3U";7(H.1M.6m)1l.2I(M.56(a));N 1l.1D=a;b.2z(1l,b.1n);b.2h(1l)}},1i:I(a,b){J a.1i&&a.1i.2s()==b.2s()},12:I(a,b,c){K d,i=0,L=a.L;7(c){7(L===17){Q(d 1q a)7(b.1w(a[d],c)===T)1I}N Q(;i<L;)7(b.1w(a[i++],c)===T)1I}N{7(L===17){Q(d 1q a)7(b.1j(a[d],d,a[d])===T)1I}N Q(K e=a[0];i<L&&b.1j(e,i,e)!==T;e=a[++i]){}}J a},1g:I(a,b,c,i,d){7(H.1R(b))b=b.1j(a,i);J 19 b==="4u"&&c=="2p"&&!z.1a(d)?b+"3k":b},1F:{1H:I(b,c){H.12((c||"").2i(/\\s+/),I(i,a){7(b.11==1&&!H.1F.4x(b.1F,a))b.1F+=(b.1F?" ":"")+a})},1X:I(b,c){7(b.11==1)b.1F=c!==17?H.4p(b.1F.2i(/\\s+/),I(a){J!H.1F.4x(c,a)}).3i(" "):""},4x:I(a,b){J a&&H.2R(b,(a.1F||a).2C().2i(/\\s+/))>-1}},7Q:I(a,b,c){K d={};Q(K e 1q b){d[e]=a.V[e];a.V[e]=b[e]}c.1j(a);Q(K e 1q b)a.V[e]=d[e]},28:I(a,b,c,d){7(b=="2f"||b=="2y"){K e,3l={2D:"5h",7R:"29",1s:"5i"},3m=b=="2f"?["6n","7S"]:["6o","7T"];I 6p(){e=b=="2f"?a.4y:a.6q;7(d==="3V")J;H.12(3m,I(){7(!d)e-=2S(H.2p(a,"5j"+6,P))||0;7(d==="3W")e+=2S(H.2p(a,"3W"+6,P))||0;N e-=2S(H.2p(a,"3V"+6+"7U",P))||0})}7(a.4y!==0)6p();N H.7Q(a,3l,6p);J 3n.3R(0,3n.9J(e))}J H.2p(a,b,c)},2p:I(c,d,e){K f,V=c.V;7(d=="1E"&&!H.1M.1E){f=H.2e(V,"1E");J f==""?"1":f}7(d.Y(/4z/i))d=E;7(!e&&V&&V[d])f=V[d];N 7(2U.5k){7(d.Y(/4z/i))d="4z";d=d.1p(/([A-Z])/g,"-$1").3X();K g=2U.5k(c,R);7(g)f=g.9K(d);7(d=="1E"&&f=="")f="1"}N 7(c.5l){K h=d.1p(/\\-(\\w)/g,I(a,b){J b.2s()});f=c.5l[d]||c.5l[h];7(!/^\\d+(3k)?$/i.1a(f)&&/^\\d/.1a(f)){K i=V.1b,7V=c.6r.1b;c.6r.1b=c.5l.1b;V.1b=f||0;f=V.9L+"3k";V.1b=i;c.6r.1b=7V}}J f},53:I(h,k,l){k=k||M;7(19 k.1T==="17")k=k.1z||k[0]&&k[0].1z||M;7(!l&&h.L===1&&19 h[0]==="1C"){K m=/^<(\\w+)\\s*\\/?>$/.2G(h[0]);7(m)J[k.1T(m[1])]}K n=[],3S=[],15=k.1T("15");H.12(h,I(i,d){7(19 d==="4u")d+=\'\';7(!d)J;7(19 d==="1C"){d=d.1p(/(<(\\w+)[^>]*?)\\/>/g,I(a,b,c){J c.Y(/^(9M|br|7W|9N|3Y|6s|9O|3Z|9P|7X|9Q)$/i)?a:b+"></"+c+">"});K e=d.1p(/^\\s+/,"").9R(0,10).3X();K f=!e.1J("<9S")&&[1,"<2r 7Y=\'7Y\'>","</2r>"]||!e.1J("<9T")&&[1,"<7Z>","</7Z>"]||e.Y(/^<(9U|1A|9V|9W|9X)/)&&[1,"<1N>","</1N>"]||!e.1J("<3T")&&[2,"<1N><1A>","</1A></1N>"]||(!e.1J("<40")||!e.1J("<9Y"))&&[3,"<1N><1A><3T>","</3T></1A></1N>"]||!e.1J("<7W")&&[2,"<1N><1A></1A><80>","</80></1N>"]||!H.1M.81&&[1,"15<15>","</15>"]||[0,"",""];15.2A=f[1]+d+f[2];1t(f[0]--)15=15.82;7(!H.1M.1A){K g=/<1A/i.1a(d),1A=!e.1J("<1N")&&!g?15.1n&&15.1n.3c:f[1]=="<1N>"&&!g?15.3c:[];Q(K j=1A.L-1;j>=0;--j)7(H.1i(1A[j],"1A")&&!1A[j].3c.L)1A[j].1h.2h(1A[j])}7(!H.1M.83&&/^\\s/.1a(d))15.2z(k.56(d.Y(/^\\s*/)[0]),15.1n);d=H.2v(15.3c)}7(d.11)n.1k(d);N n=H.6d(n,d)});7(l){Q(K i=0;n[i];i++){7(H.1i(n[i],"1l")&&(!n[i].14||n[i].14.3X()==="1D/3U")){3S.1k(n[i].1h?n[i].1h.2h(n[i]):n[i])}N{7(n[i].11===1)n.3f.1w(n,[i+1,0].5m(H.2v(n[i].1Y("1l"))));l.2I(n[i])}}J 3S}J n},2e:I(c,d,e){7(!c||c.11==3||c.11==8)J 17;K f=!H.5a(c),1G=e!==17;d=f&&H.3l[d]||d;7(c.41){K g=/2t|5f|V/.1a(d);7(d=="4t"&&c.1h)c.1h.5d;7(d 1q c&&f&&!g){7(1G){7(d=="14"&&H.1i(c,"3Y")&&c.1h)5n"14 9Z a0\'t be a1";c[d]=e}7(H.1i(c,"6t")&&c.3o(d))J c.3o(d).57;7(d=="6u"){K h=c.3o("6u");J h&&h.7H?h.1x:c.1i.Y(/(2L|3Y|1W|2r|6v)/i)?0:c.1i.Y(/^(a|7X)$/i)&&c.2t?0:17}J c[d]}7(!H.1M.V&&f&&d=="V")J H.2e(c.V,"a2",e);7(1G)c.a3(d,""+e);K i=!H.1M.84&&f&&g?c.2j(d,2):c.2j(d);J i===R?17:i}7(!H.1M.1E&&d=="1E"){7(1G){c.7M=1;c.1e=(c.1e||"").1p(/85\\([^)]*\\)/,"")+(2V(e)+\'\'=="a4"?"":"85(1E="+e*86+")")}J c.1e&&c.1e.1J("1E=")>=0?(2S(c.1e.Y(/1E=([^)]*)/)[1])/86)+\'\':""}d=d.1p(/-([a-z])/a5,I(a,b){J b.2s()});7(1G)c[d]=e;J c[d]},a6:I(a){J(a||"").1p(/^\\s+|\\s+$/g,"")},2v:I(a){K b=[];7(a!=R){K i=a.L;7(i==R||19 a==="1C"||H.1R(a)||a.5o)b[0]=a;N 1t(i)b[--i]=a[i]}J b},2R:I(a,b){Q(K i=0,L=b.L;i<L;i++)7(b[i]===a)J i;J-1},6d:I(a,b){K i=0,U,3p=a.L;7(!H.1M.a7){1t((U=b[i++])!=R)7(U.11!=8)a[3p++]=U}N 1t((U=b[i++])!=R)a[3p++]=U;J a},59:I(a){K b=[],3q={};1U{Q(K i=0,L=a.L;i<L;i++){K c=H.O(a[i]);7(!3q[c]){3q[c]=P;b.1k(a[i])}}}1V(e){b=a}J b},4p:I(a,b,c){K d=[];Q(K i=0,L=a.L;i<L;i++)7(!c!=!b(a[i],i))d.1k(a[i]);J d},2q:I(a,b){K c=[];Q(K i=0,L=a.L;i<L;i++){K d=b(a[i],i);7(d!=R)c[c.L]=d}J c.5m.1w([],c)}});K A=a8.a9.3X();H.aa={ab:(A.Y(/.+(?:ac|ad|ae|af)[\\/: ]([\\d.]+)/)||[0,\'0\'])[1],ag:/87/.1a(A),6w:/6w/.1a(A),88:/88/.1a(A)&&!/6w/.1a(A),89:/89/.1a(A)&&!/(ah|87)/.1a(A)};H.12({3r:I(a){J a.1h},ai:I(a){J H.5p(a,"1h")},aj:I(a){J H.2W(a,2,"3d")},ak:I(a){J H.2W(a,2,"3s")},al:I(a){J H.5p(a,"3d")},am:I(a){J H.5p(a,"3s")},an:I(a){J H.6x(a.1h.1n,a)},8a:I(a){J H.6x(a.1n)},7E:I(a){J H.1i(a,"ao")?a.ap||a.aq.M:H.2v(a.3c)}},I(c,d){H.1c[c]=I(a){K b=H.2q(6,d);7(a&&19 a=="1C")b=H.3P(a,b);J 6.2x(H.59(b),c,a)}});H.12({8b:"3O",ar:"7F",2z:"7G",as:"69",at:"7I"},I(d,e){H.1c[d]=I(a){K b=[],6y=H(a);Q(K i=0,l=6y.L;i<l;i++){K c=(i>0?6.68(P):6).3b();H.1c[e].1w(H(6y[i]),c);b=b.5m(c)}J 6.2x(b,d,a)}});H.12({au:I(a){H.2e(6,a,"");7(6.11==1)6.6z(a)},av:I(a){H.1F.1H(6,a)},aw:I(a){H.1F.1X(6,a)},ax:I(a,b){7(19 b!=="6l")b=!H.1F.4x(6,a);H.1F[b?"1H":"1X"](6,a)},1X:I(a){7(!a||H.1e(a,[6]).L){H("*",6).1H([6]).12(I(){H.18.1X(6);H.3t(6)});7(6.1h)6.1h.2h(6)}},55:I(){H(6).8a().1X();1t(6.1n)6.2h(6.1n)}},I(a,b){H.1c[a]=I(){J 6.12(b,1o)}});I 4A(a,b){J a[0]&&2V(H.2p(a[0],b,P),10)||0}K B="H"+21(),8c=0,6A={};H.1B({1O:{},O:I(a,b,c){a=a==y?6A:a;K d=a[B];7(!d)d=a[B]=++8c;7(b&&!H.1O[d])H.1O[d]={};7(c!==17)H.1O[d][b]=c;J b?H.1O[d][b]:d},3t:I(a,b){a=a==y?6A:a;K c=a[B];7(b){7(H.1O[c]){2X H.1O[c][b];b="";Q(b 1q H.1O[c])1I;7(!b)H.3t(a)}}N{1U{2X a[B]}1V(e){7(a.6z)a.6z(B)}2X H.1O[c]}},2E:I(a,b,c){7(a){b=(b||"2a")+"2E";K q=H.O(a,b);7(!q||H.3a(c))q=H.O(a,b,H.2v(c));N 7(c)q.1k(c)}J q},4B:I(a,b){K c=H.2E(a,b),1c=c.3u();7(!b||b==="2a")1c=c[0];7(1c!==17)1c.1j(a)}});H.1c.1B({O:I(a,b){K c=a.2i(".");c[1]=c[1]?"."+c[1]:"";7(b===17){K d=6.6B("ay"+c[1]+"!",[c[0]]);7(d===17&&6.L)d=H.O(6[0],a);J d===17&&c[1]?6.O(c[0]):d}N J 6.1P("az"+c[1]+"!",[c[0],b]).12(I(){H.O(6,a,b)})},3t:I(a){J 6.12(I(){H.3t(6,a)})},2E:I(b,c){7(19 b!=="1C"){c=b;b="2a"}7(c===17)J H.2E(6[0],b);J 6.12(I(){K a=H.2E(6,b,c);7(b=="2a"&&a.L==1)a[0].1j(6)})},4B:I(a){J 6.12(I(){H.4B(6,a)})}});(I(){K k=/((?:\\((?:\\([^()]+\\)|[^()]+)+\\)|\\[(?:\\[[^[\\]]*\\]|[\'"][^\'"]*[\'"]|[^[\\]\'"]+)+\\]|\\\\.|[^ >+~,(\\[\\\\]+)+|[>+~])(\\s*,\\s*)?/g,3q=0,2C=7N.27.2C;K o=I(a,b,c,d){c=c||[];b=b||M;7(b.11!==1&&b.11!==9)J[];7(!a||19 a!=="1C"){J c}K e=[],m,1G,1K,2b,aA,5q,6C=P;k.aB=0;1t((m=k.2G(a))!==R){e.1k(m[1]);7(m[2]){5q=3v.aC;1I}}7(e.L>1&&q.2G(a)){7(e.L===2&&p.2M[e[0]]){1G=x(e[0]+e[1],b)}N{1G=p.2M[e[0]]?[b]:o(e.3u(),b);1t(e.L){a=e.3u();7(p.2M[a])a+=e.3u();1G=x(a,1G)}}}N{K f=d?{3g:e.2N(),1G:t(d)}:o.1v(e.2N(),e.L===1&&b.1h?b.1h:b,w(b));1G=o.1e(f.3g,f.1G);7(e.L>0){1K=t(1G)}N{6C=T}1t(e.L){K g=e.2N(),2N=g;7(!p.2M[g]){g=""}N{2N=e.2N()}7(2N==R){2N=b}p.2M[g](1K,2N,w(b))}}7(!1K){1K=1G}7(!1K){5n"8d 3w, 8e 8f: "+(g||a);}7(2C.1j(1K)==="[1W 2w]"){7(!6C){c.1k.1w(c,1K)}N 7(b.11===1){Q(K i=0;1K[i]!=R;i++){7(1K[i]&&(1K[i]===P||1K[i].11===1&&v(b,1K[i]))){c.1k(1G[i])}}}N{Q(K i=0;1K[i]!=R;i++){7(1K[i]&&1K[i].11===1){c.1k(1G[i])}}}}N{t(1K,c)}7(5q){o(5q,b,c,d);7(u){4C=T;c.3e(u);7(4C){Q(K i=1;i<c.L;i++){7(c[i]===c[i-1]){c.3f(i--,1)}}}}}J c};o.5r=I(a,b){J o(a,R,R,b)};o.1v=I(a,b,c){K d,Y;7(!a){J[]}Q(K i=0,l=p.5s.L;i<l;i++){K e=p.5s[i],Y;7((Y=p.Y[e].2G(a))){K f=3v.aD;7(f.6D(f.L-1)!=="\\\\"){Y[1]=(Y[1]||"").1p(/\\\\/g,"");d=p.1v[e](Y,b,c);7(d!=R){a=a.1p(p.Y[e],"");1I}}}}7(!d){d=b.1Y("*")}J{1G:d,3g:a}};o.1e=I(a,b,c,d){K e=a,22=[],2Y=b,Y,3x,8g=b&&b[0]&&w(b[0]);1t(a&&b.L){Q(K f 1q p.1e){7((Y=p.Y[f].2G(a))!=R){K g=p.1e[f],42,4D;3x=T;7(2Y==22){22=[]}7(p.6E[f]){Y=p.6E[f](Y,2Y,c,22,d,8g);7(!Y){3x=42=P}N 7(Y===P){7L}}7(Y){Q(K i=0;(4D=2Y[i])!=R;i++){7(4D){42=g(4D,Y,i,2Y);K h=d^!!42;7(c&&42!=R){7(h){3x=P}N{2Y[i]=T}}N 7(h){22.1k(4D);3x=P}}}}7(42!==17){7(!c){2Y=22}a=a.1p(p.Y[f],"");7(!3x){J[]}1I}}}7(a==e){7(3x==R){5n"8d 3w, 8e 8f: "+a;}N{1I}}e=a}J 2Y};K p=o.3y={5s:["3z","6F","43"],Y:{3z:/#((?:[\\w\\44-\\4E-]|\\\\.)+)/,4F:/\\.((?:[\\w\\44-\\4E-]|\\\\.)+)/,6F:/\\[2g=[\'"]*((?:[\\w\\44-\\4E-]|\\\\.)+)[\'"]*\\]/,6G:/\\[\\s*((?:[\\w\\44-\\4E-]|\\\\.)+)\\s*(?:(\\S?=)\\s*([\'"]*)(.*?)\\3|)\\s*\\]/,43:/^((?:[\\w\\44-\\aE\\*4n-]|\\\\.)+)/,5t:/:(8h|2W|3A|2T)-aF(?:\\((5u|5v|[\\aG+-]*)\\))?/,3Q:/:(2W|6i|8i|8j|2T|3A|5u|5v)(?:\\((\\d*)\\))?(?=[^-]|$)/,4G:/:((?:[\\w\\44-\\4E-]|\\\\.)+)(?:\\(([\'"]*)((?:\\([^\\)]+\\)|[^\\2\\(\\)]*)+)\\2\\))?/},6H:{"45":"1F","Q":"8k"},5w:{2t:I(a){J a.2j("2t")}},2M:{"+":I(a,b,c){K d=19 b==="1C",6I=d&&!/\\W/.1a(b),6J=d&&!6I;7(6I&&!c){b=b.2s()}Q(K i=0,l=a.L,U;i<l;i++){7((U=a[i])){1t((U=U.3s)&&U.11!==1){}a[i]=6J||U&&U.1i===b?U||T:U===b}}7(6J){o.1e(b,a,P)}},">":I(a,b,c){K d=19 b==="1C";7(d&&!/\\W/.1a(b)){b=c?b:b.2s();Q(K i=0,l=a.L;i<l;i++){K e=a[i];7(e){K f=e.1h;a[i]=f.1i===b?f:T}}}N{Q(K i=0,l=a.L;i<l;i++){K e=a[i];7(e){a[i]=d?e.1h:e.1h===b}}7(d){o.1e(b,a,P)}}},"":I(a,b,c){K d=3q++,46=6K;7(!b.Y(/\\W/)){K e=b=c?b:b.2s();46=6L}46("1h",b,d,a,e,c)},"~":I(a,b,c){K d=3q++,46=6K;7(19 b==="1C"&&!b.Y(/\\W/)){K e=b=c?b:b.2s();46=6L}46("3s",b,d,a,e,c)}},1v:{3z:I(a,b,c){7(19 b.3N!=="17"&&!c){K m=b.3N(a[1]);J m?[m]:[]}},6F:I(a,b,c){7(19 b.8l!=="17"){K d=[],3B=b.8l(a[1]);Q(K i=0,l=3B.L;i<l;i++){7(3B[i].2j("2g")===a[1]){d.1k(3B[i])}}J d.L===0?R:d}},43:I(a,b){J b.1Y(a[1])}},6E:{4F:I(a,b,c,d,e,f){a=" "+a[1].1p(/\\\\/g,"")+" ";7(f){J a}Q(K i=0,U;(U=b[i])!=R;i++){7(U){7(e^(U.1F&&(" "+U.1F+" ").1J(a)>=0)){7(!c)d.1k(U)}N 7(c){b[i]=T}}}J T},3z:I(a){J a[1].1p(/\\\\/g,"")},43:I(a,b){Q(K i=0;b[i]===T;i++){}J b[i]&&w(b[i])?a[1]:a[1].2s()},5t:I(a){7(a[1]=="2W"){K b=/(-?)(\\d*)n((?:\\+|-)?\\d*)/.2G(a[2]=="5u"&&"2n"||a[2]=="5v"&&"2n+1"||!/\\D/.1a(a[2])&&"aH+"+a[2]||a[2]);a[2]=(b[1]+(b[2]||1))-0;a[3]=b[3]-0}a[0]=3q++;J a},6G:I(a,b,c,d,e,f){K g=a[1].1p(/\\\\/g,"");7(!f&&p.6H[g]){a[1]=p.6H[g]}7(a[2]==="~="){a[4]=" "+a[4]+" "}J a},4G:I(a,b,c,d,e){7(a[1]==="4s"){7(a[3].Y(k).L>1||/^\\w/.1a(a[3])){a[3]=o(a[3],R,R,b)}N{K f=o.1e(a[3],b,c,P^e);7(!c){d.1k.1w(d,f)}J T}}N 7(p.Y.3Q.1a(a[0])||p.Y.5t.1a(a[0])){J P}J a},3Q:I(a){a.8m(P);J a}},47:{aI:I(a){J a.5x===T&&a.14!=="29"},5x:I(a){J a.5x===P},5e:I(a){J a.5e===P},4t:I(a){a.1h.5d;J a.4t===P},3r:I(a){J!!a.1n},55:I(a){J!a.1n},4x:I(a,i,b){J!!o(b[3],a).L},aJ:I(a){J/h\\d/i.1a(a.1i)},1D:I(a){J"1D"===a.14},6g:I(a){J"6g"===a.14},6h:I(a){J"6h"===a.14},6M:I(a){J"6M"===a.14},5y:I(a){J"5y"===a.14},6N:I(a){J"6N"===a.14},8n:I(a){J"8n"===a.14},8o:I(a){J"8o"===a.14},2L:I(a){J"2L"===a.14||a.1i.2s()==="aK"},3Y:I(a){J/3Y|2r|6v|2L/i.1a(a.1i)}},8p:{2T:I(a,i){J i===0},3A:I(a,i,b,c){J i===c.L-1},5u:I(a,i){J i%2===0},5v:I(a,i){J i%2===1},8j:I(a,i,b){J i<b[3]-0},8i:I(a,i,b){J i>b[3]-0},2W:I(a,i,b){J b[3]-0==i},6i:I(a,i,b){J b[3]-0==i}},1e:{4G:I(a,b,i,c){K d=b[1],1e=p.47[d];7(1e){J 1e(a,i,b,c)}N 7(d==="6O"){J(a.7K||a.aL||"").1J(b[3])>=0}N 7(d==="4s"){K e=b[3];Q(K i=0,l=e.L;i<l;i++){7(e[i]===a){J T}}J P}},5t:I(a,b){K c=b[1],23=a;aM(c){5z\'8h\':5z\'2T\':1t(23=23.3s){7(23.11===1)J T}7(c==\'2T\')J P;23=a;5z\'3A\':1t(23=23.3d){7(23.11===1)J T}J P;5z\'2W\':K d=b[2],3A=b[3];7(d==1&&3A==0){J P}K e=b[0],3r=a.1h;7(3r&&(3r.2Z!==e||!a.6P)){K f=0;Q(23=3r.1n;23;23=23.3d){7(23.11===1){23.6P=++f}}3r.2Z=e}K g=a.6P-3A;7(d==0){J g==0}N{J(g%d==0&&g/d>=0)}}},3z:I(a,b){J a.11===1&&a.2j("2d")===b},43:I(a,b){J(b==="*"&&a.11===1)||a.1i===b},4F:I(a,b){J(" "+(a.1F||a.2j("45"))+" ").1J(b)>-1},6G:I(a,b){K c=b[1],22=p.5w[c]?p.5w[c](a):a[c]!=R?a[c]:a.2j(c),1x=22+"",s=b[2],2b=b[4];J 22==R?s==="!=":s==="="?1x===2b:s==="*="?1x.1J(2b)>=0:s==="~="?(" "+1x+" ").1J(2b)>=0:!2b?1x&&22!==T:s==="!="?1x!=2b:s==="^="?1x.1J(2b)===0:s==="$="?1x.6D(1x.L-2b.L)===2b:s==="|="?1x===2b||1x.6D(0,2b.L+1)===2b+"-":T},3Q:I(a,b,i,c){K d=b[2],1e=p.8p[d];7(1e){J 1e(a,i,b,c)}}}};K q=p.Y.3Q;Q(K s 1q p.Y){p.Y[s]=3v(p.Y[s].8q+/(?![^\\[]*\\])(?![^\\(]*\\))/.8q)}K t=I(a,b){a=2w.27.1S.1j(a);7(b){b.1k.1w(b,a);J b}J a};1U{2w.27.1S.1j(M.1y.3c)}1V(e){t=I(a,b){K c=b||[];7(2C.1j(a)==="[1W 2w]"){2w.27.1k.1w(c,a)}N{7(19 a.L==="4u"){Q(K i=0,l=a.L;i<l;i++){c.1k(a[i])}}N{Q(K i=0;a[i];i++){c.1k(a[i])}}}J c}}K u;7(M.1y.5A){u=I(a,b){K c=a.5A(b)&4?-1:a===b?0:1;7(c===0){4C=P}J c}}N 7("6Q"1q M.1y){u=I(a,b){K c=a.6Q-b.6Q;7(c===0){4C=P}J c}}N 7(M.6R){u=I(a,b){K c=a.1z.6R(),5B=b.1z.6R();c.8r(a);c.8s(P);5B.8r(b);5B.8s(P);K d=c.aN(aO.aP,5B);7(d===0){4C=P}J d}}(I(){K d=M.1T("6t"),2d="1l"+(2Q 6k).8t();d.2A="<3Y 2g=\'"+2d+"\'/>";K e=M.1y;e.2z(d,e.1n);7(!!M.3N(2d)){p.1v.3z=I(a,b,c){7(19 b.3N!=="17"&&!c){K m=b.3N(a[1]);J m?m.2d===a[1]||19 m.3o!=="17"&&m.3o("2d").57===a[1]?[m]:17:[]}};p.1e.3z=I(a,b){K c=19 a.3o!=="17"&&a.3o("2d");J a.11===1&&c&&c.57===b}}e.2h(d)})();(I(){K e=M.1T("15");e.2I(M.aQ(""));7(e.1Y("*").L>0){p.1v.43=I(a,b){K c=b.1Y(a[1]);7(a[1]==="*"){K d=[];Q(K i=0;c[i];i++){7(c[i].11===1){d.1k(c[i])}}c=d}J c}}e.2A="<a 2t=\'#\'></a>";7(e.1n&&19 e.1n.2j!=="17"&&e.1n.2j("2t")!=="#"){p.5w.2t=I(a){J a.2j("2t",2)}}})();7(M.5C)(I(){K f=o,15=M.1T("15");15.2A="<p 45=\'8u\'></p>";7(15.5C&&15.5C(".8u").L===0){J}o=I(a,b,c,d){b=b||M;7(!d&&b.11===9&&!w(b)){1U{J t(b.5C(a),c)}1V(e){}}J f(a,b,c,d)};o.1v=f.1v;o.1e=f.1e;o.3y=f.3y;o.5r=f.5r})();7(M.48&&M.1y.48)(I(){K d=M.1T("15");d.2A="<15 45=\'1a e\'></15><15 45=\'1a\'></15>";7(d.48("e").L===0)J;d.82.1F="e";7(d.48("e").L===1)J;p.5s.3f(1,0,"4F");p.1v.4F=I(a,b,c){7(19 b.48!=="17"&&!c){J b.48(a[1])}}})();I 6L(a,b,c,d,e,f){K g=a=="3s"&&!f;Q(K i=0,l=d.L;i<l;i++){K h=d[i];7(h){7(g&&h.11===1){h.2Z=c;h.49=i}h=h[a];K j=T;1t(h){7(h.2Z===c){j=d[h.49];1I}7(h.11===1&&!f){h.2Z=c;h.49=i}7(h.1i===b){j=h;1I}h=h[a]}d[i]=j}}}I 6K(a,b,c,d,e,f){K g=a=="3s"&&!f;Q(K i=0,l=d.L;i<l;i++){K h=d[i];7(h){7(g&&h.11===1){h.2Z=c;h.49=i}h=h[a];K j=T;1t(h){7(h.2Z===c){j=d[h.49];1I}7(h.11===1){7(!f){h.2Z=c;h.49=i}7(19 b!=="1C"){7(h===b){j=P;1I}}N 7(o.1e(b,[h]).L>0){j=h;1I}}h=h[a]}d[i]=j}}}K v=M.5A?I(a,b){J a.5A(b)&16}:I(a,b){J a!==b&&(a.6O?a.6O(b):P)};K w=I(a){J a.11===9&&a.1y.1i!=="7O"||!!a.1z&&w(a.1z)};K x=I(a,b){K c=[],6S="",Y,4v=b.11?[b]:b;1t((Y=p.Y.4G.2G(a))){6S+=Y[0];a=a.1p(p.Y.4G,"")}a=p.2M[a]?a+"*":a;Q(K i=0,l=4v.L;i<l;i++){o(a,4v[i],c)}J o.1e(6S,c)};H.1v=o;H.1e=o.1e;H.3g=o.3y;H.3g[":"]=H.3g.47;o.3y.47.29=I(a){J a.4y===0||a.6q===0};o.3y.47.8v=I(a){J a.4y>0||a.6q>0};o.3y.47.aR=I(b){J H.4p(H.4H,I(a){J b===a.U}).L};H.3P=I(a,b,c){7(c){a=":4s("+a+")"}J o.5r(a,b)};H.5p=I(a,b){K c=[],2k=a[b];1t(2k&&2k!=M){7(2k.11==1)c.1k(2k);2k=2k[b]}J c};H.2W=I(a,b,c,d){b=b||1;K e=0;Q(;a;a=a[c])7(a.11==1&&++e==b)1I;J a};H.6x=I(n,a){K r=[];Q(;n;n=n.3d){7(n.11==1&&n!=a)r.1k(n)}J r};J;y.aS=o})();H.18={1H:I(e,f,g,h){7(e.11==3||e.11==8)J;7(e.5o&&e!=y)e=y;7(!g.24)g.24=6.24++;7(h!==17){K i=g;g=6.4a(i);g.O=h}K j=H.O(e,"2B")||H.O(e,"2B",{}),1L=H.O(e,"1L")||H.O(e,"1L",I(){J 19 H!=="17"&&!H.18.6T?H.18.1L.1w(1o.4I.U,1o):17});1L.U=e;H.12(f.2i(/\\s+/),I(a,b){K c=b.2i(".");b=c.3u();g.14=c.1S().3e().3i(".");K d=j[b];7(H.18.4J[b])H.18.4J[b].4K.1j(e,h,c);7(!d){d=j[b]={};7(!H.18.4b[b]||H.18.4b[b].4K.1j(e,h,c)===T){7(e.5D)e.5D(b,1L,T);N 7(e.4c)e.4c("5E"+b,1L)}}d[g.24]=g;H.18.2l[b]=P});e=R},24:1,2l:{},1X:I(f,g,h){7(f.11==3||f.11==8)J;K i=H.O(f,"2B"),4d,54;7(i){7(g===17||(19 g==="1C"&&g.aT(0)=="."))Q(K j 1q i)6.1X(f,j+(g||""));N{7(g.14){h=g.6U;g=g.14}H.12(g.2i(/\\s+/),I(a,b){K c=b.2i(".");b=c.3u();K d=3v("(^|\\\\.)"+c.1S().3e().3i(".*\\\\.")+"(\\\\.|$)");7(i[b]){7(h)2X i[b][h.24];N Q(K e 1q i[b])7(d.1a(i[b][e].14))2X i[b][e];7(H.18.4J[b])H.18.4J[b].4L.1j(f,c);Q(4d 1q i[b])1I;7(!4d){7(!H.18.4b[b]||H.18.4b[b].4L.1j(f,c)===T){7(f.6V)f.6V(b,H.O(f,"1L"),T);N 7(f.5F)f.5F("5E"+b,H.O(f,"1L"))}4d=R;2X i[b]}}})}Q(4d 1q i)1I;7(!4d){K k=H.O(f,"1L");7(k)k.U=R;H.3t(f,"2B");H.3t(f,"1L")}}},1P:I(a,b,c,d){K f=a.14||a;7(!d){a=19 a==="1W"?a[B]?a:H.1B(H.3C(f),a):H.3C(f);7(f.1J("!")>=0){a.14=f=f.1S(0,-1);a.8w=P}7(!c){a.3D();7(6.2l[f])H.12(H.1O,I(){7(6.2B&&6.2B[f])H.18.1P(a,b,6.1L.U)})}7(!c||c.11==3||c.11==8)J 17;a.22=17;a.2O=c;b=H.2v(b);b.8m(a)}a.6W=c;K g=H.O(c,"1L");7(g)g.1w(c,b);7((!c[f]||(H.1i(c,\'a\')&&f=="5G"))&&c["5E"+f]&&c["5E"+f].1w(c,b)===T)a.22=T;7(!d&&c[f]&&!a.6X()&&!(H.1i(c,\'a\')&&f=="5G")){6.6T=P;1U{c[f]()}1V(e){}}6.6T=T;7(!a.6Y()){K h=c.1h||c.1z;7(h)H.18.1P(a,b,h,P)}},1L:I(a){K b,5H;a=1o[0]=H.18.8x(a||y.18);a.6W=6;K c=a.14.2i(".");a.14=c.3u();b=!c.L&&!a.8w;K d=3v("(^|\\\\.)"+c.1S().3e().3i(".*\\\\.")+"(\\\\.|$)");5H=(H.O(6,"2B")||{})[a.14];Q(K j 1q 5H){K e=5H[j];7(b||d.1a(e.14)){a.6U=e;a.O=e.O;K f=e.1w(6,1o);7(f!==17){a.22=f;7(f===T){a.3E();a.3D()}}7(a.6Z())1I}}},3l:"aU aV aW aX 2L aY 4M 70 8y 71 6W O aZ b0 5I 6U 72 73 b1 b2 74 8z b3 b4 5J b5 b6 b7 8A 2O 8B b8 b9 3m".2i(" "),8x:I(a){7(a[B])J a;K b=a;a=H.3C(b);Q(K i=6.3l.L,1g;i;){1g=6.3l[--i];a[1g]=b[1g]}7(!a.2O)a.2O=a.8A||M;7(a.2O.11==3)a.2O=a.2O.1h;7(!a.5J&&a.5I)a.5J=a.5I==a.2O?a.8B:a.5I;7(a.74==R&&a.70!=R){K c=M.1y,1d=M.1d;a.74=a.70+(c&&c.30||1d&&1d.30||0)-(c.4N||0);a.8z=a.8y+(c&&c.31||1d&&1d.31||0)-(c.4O||0)}7(!a.3m&&((a.4M||a.4M===0)?a.4M:a.72))a.3m=a.4M||a.72;7(!a.73&&a.71)a.73=a.71;7(!a.3m&&a.2L)a.3m=(a.2L&1?1:(a.2L&2?3:(a.2L&4?2:0)));J a},4a:I(a,b){b=b||I(){J a.1w(6,1o)};b.24=a.24=a.24||b.24||6.24++;J b},4b:{2H:{4K:75,4L:I(){}}},4J:{4P:{4K:I(a,b){H.18.1H(6,b[0],76)},4L:I(a){7(a.L){K b=0,2g=3v("(^|\\\\.)"+a[0]+"(\\\\.|$)");H.12((H.O(6,"2B").4P||{}),I(){7(2g.1a(6.14))b++});7(b<1)H.18.1X(6,a[0],76)}}}}};H.3C=I(a){7(!6.3E)J 2Q H.3C(a);7(a&&a.14){6.77=a;6.14=a.14}N 6.14=a;6.ba=21();6[B]=P};I 5K(){J T}I 5L(){J P}H.3C.27={3E:I(){6.6X=5L;K e=6.77;7(!e)J;7(e.3E)e.3E();e.bb=T},3D:I(){6.6Y=5L;K e=6.77;7(!e)J;7(e.3D)e.3D();e.bc=P},bd:I(){6.6Z=5L;6.3D()},6X:5K,6Y:5K,6Z:5K};K C=I(a){K b=a.5J;1t(b&&b!=6)1U{b=b.1h}1V(e){b=6}7(b!=6){a.14=a.O;H.18.1L.1w(6,1o)}};H.12({8C:\'78\',8D:\'79\'},I(a,b){H.18.4b[b]={4K:I(){H.18.1H(6,a,C,b)},4L:I(){H.18.1X(6,a,C)}}});H.1c.1B({4Q:I(a,b,c){J a=="7a"?6.3h(a,b,c):6.12(I(){H.18.1H(6,a,c||b,c&&b)})},3h:I(b,c,d){K e=H.18.4a(d||c,I(a){H(6).7b(a,e);J(d||c).1w(6,1o)});J 6.12(I(){H.18.1H(6,b,e,d&&c)})},7b:I(a,b){J 6.12(I(){H.18.1X(6,a,b)})},1P:I(a,b){J 6.12(I(){H.18.1P(a,b,6)})},6B:I(a,b){7(6[0]){K c=H.3C(a);c.3E();c.3D();H.18.1P(c,b,6[0]);J c.22}},3F:I(b){K c=1o,i=1;1t(i<c.L)H.18.4a(b,c[i++]);J 6.5G(H.18.4a(b,I(a){6.7c=(6.7c||0)%i;a.3E();J c[6.7c++].1w(6,1o)||T}))},bf:I(a,b){J 6.78(a).79(b)},2H:I(a){75();7(H.4R)a.1j(M,H);N H.4S.1k(a);J 6},4P:I(a,b){K c=H.18.4a(b);c.24+=6.1Q+a;H(M).4Q(7d(a,6.1Q),6.1Q,c);J 6},bg:I(a,b){H(M).7b(7d(a,6.1Q),b?{24:b.24+6.1Q+a}:R);J 6}});I 76(c){K d=3v("(^|\\\\.)"+c.14+"(\\\\.|$)"),5M=P,5N=[];H.12(H.O(6,"2B").4P||[],I(i,a){7(d.1a(a.14)){K b=H(c.2O).4q(a.O)[0];7(b)5N.1k({U:b,1c:a})}});5N.3e(I(a,b){J H.O(a.U,"4q")-H.O(b.U,"4q")});H.12(5N,I(){7(6.1c.1j(6.U,c,6.1c.O)===T)J(5M=T)});J 5M}I 7d(a,b){J["4P",a,b.1p(/\\./g,"`").1p(/ /g,"|")].3i(".")}H.1B({4R:T,4S:[],2H:I(){7(!H.4R){H.4R=P;7(H.4S){H.12(H.4S,I(){6.1j(M,H)});H.4S=R}H(M).6B("2H")}}});K D=T;I 75(){7(D)J;D=P;7(M.5D){M.5D("8E",I(){M.6V("8E",1o.4I,T);H.2H()},T)}N 7(M.4c){M.4c("5O",I(){7(M.4e==="25"){M.5F("5O",1o.4I);H.2H()}});7(M.1y.8F&&y==y.1m)(I(){7(H.4R)J;1U{M.1y.8F("1b")}1V(3w){8G(1o.4I,0);J}H.2H()})()}H.18.1H(y,"5P",H.2H)}H.12(("bh,bi,5P,bj,5Q,7a,5G,bk,"+"bl,bm,bn,8C,8D,78,79,"+"bo,2r,6N,bp,bq,bs,3w").2i(","),I(i,b){H.1c[b]=I(a){J a?6.4Q(b,a):6.1P(b)}});H(y).4Q(\'7a\',I(){Q(K a 1q H.1O)7(a!=1&&H.1O[a].1L)H.18.1X(H.1O[a].1L.U)});(I(){H.1M={};K b=M.1y,1l=M.1T("1l"),15=M.1T("15"),2d="1l"+(2Q 6k).8t();15.V.1s="3G";15.2A=\'   <6s/><1N></1N><a 2t="/a" V="bt:8H;4z:1b;1E:.5;">a</a><2r><5c>1D</5c></2r><1W><3Z/></1W>\';K c=15.1Y("*"),a=15.1Y("a")[0];7(!c||!c.L||!a){J}H.1M={83:15.1n.11==3,1A:!15.1Y("1A").L,bu:!!15.1Y("1W")[0].1Y("*").L,81:!!15.1Y("6s").L,V:/8H/.1a(a.2j("V")),84:a.2j("2t")==="/a",1E:a.V.1E==="0.5",4T:!!a.V.4T,6m:T,6a:P,4f:R};1l.14="1D/3U";1U{1l.2I(M.56("bv."+2d+"=1;"))}1V(e){}b.2z(1l,b.1n);7(y[2d]){H.1M.6m=P;2X y[2d]}b.2h(1l);7(15.4c&&15.8I){15.4c("7e",I(){H.1M.6a=T;15.5F("7e",1o.4I)});15.5b(P).8I("7e")}H(I(){K a=M.1T("15");a.V.2f=a.V.8J="32";M.1d.2I(a);H.4f=H.1M.4f=a.4y===2;M.1d.2h(a).V.1s=\'3G\'})})();K E=H.1M.4T?"4T":"8K";H.3l={"Q":"8k","45":"1F","4z":E,4T:E,8K:E,bw:"bx",by:"bz",8L:"bA",bB:"bC",bD:"6u"};H.1c.1B({8M:H.1c.5P,5P:I(c,d,e){7(19 c!=="1C")J 6.8M(c);K f=c.1J(" ");7(f>=0){K g=c.1S(f,c.L);c=c.1S(0,f)}K h="3H";7(d)7(H.1R(d)){e=d;d=R}N 7(19 d==="1W"){d=H.3Z(d);h="8N"}K i=6;H.4w({1r:c,14:h,1Z:"2J",O:d,25:I(a,b){7(b=="2m"||b=="8O")i.2J(g?H("<15/>").3O(a.5R.1p(/<1l(.|\\s)*?\\/1l>/g,"")).1v(g):a.5R);7(e)i.12(e,[a.5R,b,a])}});J 6},bE:I(){J H.3Z(6.8P())},8P:I(){J 6.2q(I(){J 6.8Q?H.2v(6.8Q):6}).1e(I(){J 6.2g&&!6.5x&&(6.5e||/2r|6v/i.1a(6.1i)||/1D|29|5y|bF/i.1a(6.14))}).2q(I(i,b){K c=H(6).6e();J c==R?R:H.3a(c)?H.2q(c,I(a,i){J{2g:b.2g,1x:a}}):{2g:b.2g,1x:c}}).3b()}});H.12("8R,5S,8S,8T,8U,8V".2i(","),I(i,o){H.1c[o]=I(f){J 6.4Q(o,f)}});K F=21();H.1B({3b:I(a,b,c,d){7(H.1R(b)){c=b;b=R}J H.4w({14:"3H",1r:a,O:b,2m:c,1Z:d})},bG:I(a,b){J H.3b(a,R,b,"1l")},bH:I(a,b,c){J H.3b(a,b,c,"4g")},bI:I(a,b,c,d){7(H.1R(b)){c=b;b={}}J H.4w({14:"8N",1r:a,O:b,2m:c,1Z:d})},bJ:I(a){H.1B(H.7f,a)},7f:{1r:5T.2t,2l:P,14:"3H",8W:"5U/x-bK-6t-bL",8X:P,3j:P,8Y:I(){J y.8Z?2Q 8Z("bM.bN"):2Q 90()},5V:{33:"5U/33, 1D/33",2J:"1D/2J",1l:"1D/3U, 5U/3U",4g:"5U/4g, 1D/3U",1D:"1D/bO",4h:"*/*"}},5W:{},4w:I(s){s=H.1B(P,s,H.1B(P,{},H.7f,s));K c,3I=/=\\?(&|$)/g,26,O,14=s.14.2s();7(s.O&&s.8X&&19 s.O!=="1C")s.O=H.3Z(s.O);7(s.1Z=="5X"){7(14=="3H"){7(!s.1r.Y(3I))s.1r+=(s.1r.Y(/\\?/)?"&":"?")+(s.5X||"91")+"=?"}N 7(!s.O||!s.O.Y(3I))s.O=(s.O?s.O+"&":"")+(s.5X||"91")+"=?";s.1Z="4g"}7(s.1Z=="4g"&&(s.O&&s.O.Y(3I)||s.1r.Y(3I))){c="5X"+F++;7(s.O)s.O=(s.O+"").1p(3I,"="+c+"$1");s.1r=s.1r.1p(3I,"="+c+"$1");s.1Z="1l";y[c]=I(a){O=a;2m();25();y[c]=17;1U{2X y[c]}1V(e){}7(h)h.2h(i)}}7(s.1Z=="1l"&&s.1O==R)s.1O=T;7(s.1O===T&&14=="3H"){K d=21();K f=s.1r.1p(/(\\?|&)4n=.*?(&|$)/,"$bP="+d+"$2");s.1r=f+((f==s.1r)?(s.1r.Y(/\\?/)?"&":"?")+"4n="+d:"")}7(s.O&&14=="3H"){s.1r+=(s.1r.Y(/\\?/)?"&":"?")+s.O;s.O=R}7(s.2l&&!H.4U++)H.18.1P("8R");K g=/^(\\w+:)?\\/\\/([^\\/?#]+)/.2G(s.1r);7(s.1Z=="1l"&&14=="3H"&&g&&(g[1]&&g[1]!=5T.92||g[2]!=5T.bQ)){K h=M.1Y("7P")[0];K i=M.1T("1l");i.5f=s.1r;7(s.93)i.bR=s.93;7(!c){K j=T;i.94=i.5O=I(){7(!j&&(!6.4e||6.4e=="bS"||6.4e=="25")){j=P;2m();25();i.94=i.5O=R;h.2h(i)}}}h.2I(i);J 17}K k=T;K l=s.8Y();7(s.95)l.96(14,s.1r,s.3j,s.95,s.5y);N l.96(14,s.1r,s.3j);1U{7(s.O)l.5Y("bT-bU",s.8W);7(s.7g)l.5Y("bV-7h-bW",H.5W[s.1r]||"bX, bY bZ c0 7i:7i:7i c1");l.5Y("X-c2-c3","90");l.5Y("c4",s.1Z&&s.5V[s.1Z]?s.5V[s.1Z]+", */*":s.5V.4h)}1V(e){}7(s.97&&s.97(l,s)===T){7(s.2l&&!--H.4U)H.18.1P("5S");l.98();J T}7(s.2l)H.18.1P("8V",[l,s]);K m=I(a){7(l.4e==0){7(n){7j(n);n=R;7(s.2l&&!--H.4U)H.18.1P("5S")}}N 7(!k&&l&&(l.4e==4||a=="4i")){k=P;7(n){7j(n);n=R}26=a=="4i"?"4i":!H.99(l)?"3w":s.7g&&H.9a(l,s.1r)?"8O":"2m";7(26=="2m"){1U{O=H.9b(l,s.1Z,s)}1V(e){26="7k"}}7(26=="2m"){K b;1U{b=l.7l("9c-7h")}1V(e){}7(s.7g&&b)H.5W[s.1r]=b;7(!c)2m()}N H.7m(s,l,26);25();7(a)l.98();7(s.3j)l=R}};7(s.3j){K n=5o(m,13);7(s.4i>0)8G(I(){7(l&&!k)m("4i")},s.4i)}1U{l.c5(s.O)}1V(e){H.7m(s,l,R,e)}7(!s.3j)m();I 2m(){7(s.2m)s.2m(O,26);7(s.2l)H.18.1P("8U",[l,s])}I 25(){7(s.25)s.25(l,26);7(s.2l)H.18.1P("8S",[l,s]);7(s.2l&&!--H.4U)H.18.1P("5S")}J l},7m:I(s,a,b,e){7(s.3w)s.3w(a,b,e);7(s.2l)H.18.1P("8T",[a,s,e])},4U:0,99:I(a){1U{J!a.26&&5T.92=="6M:"||(a.26>=9d&&a.26<c6)||a.26==9e||a.26==c7}1V(e){}J T},9a:I(a,b){1U{K c=a.7l("9c-7h");J a.26==9e||c==H.5W[b]}1V(e){}J T},9b:I(a,b,s){K c=a.7l("c8-14"),33=b=="33"||!b&&c&&c.1J("33")>=0,O=33?a.c9:a.5R;7(33&&O.1y.41=="7k")5n"7k";7(s&&s.9f)O=s.9f(O,b);7(19 O==="1C"){7(b=="1l")H.6j(O);7(b=="4g")O=y["ca"]("("+O+")")}J O},3Z:I(a){K s=[];I 1H(a,b){s[s.L]=9g(a)+\'=\'+9g(b)};7(H.3a(a)||a.65)H.12(a,I(){1H(6.2g,6.1x)});N Q(K j 1q a)7(H.3a(a[j]))H.12(a[j],I(){1H(j,6)});N 1H(j,H.1R(a[j])?a[j]():a[j]);J s.3i("&").1p(/%20/g,"+")}});K G={},4V,7n=[["2y","4j","cb","cc","cd"],["2f","7o","ce","8J","cf"],["1E"]];I 3J(a,b){K c={};H.12(7n.5m.1w([],7n.1S(0,b)),I(){c[6]=a});J c}H.1c.1B({2o:I(a,b){7(a){J 6.4k(3J("2o",3),a,b)}N{Q(K i=0,l=6.L;i<l;i++){K c=H.O(6[i],"4W");6[i].V.1s=c||"";7(H.28(6[i],"1s")==="3G"){K d=6[i].41,1s;7(G[d]){1s=G[d]}N{K e=H("<"+d+" />").8b("1d");1s=e.28("1s");7(1s==="3G")1s="5i";e.1X();G[d]=1s}H.O(6[i],"4W",1s)}}Q(K i=0,l=6.L;i<l;i++){6[i].V.1s=H.O(6[i],"4W")||""}J 6}},2c:I(a,b){7(a){J 6.4k(3J("2c",3),a,b)}N{Q(K i=0,l=6.L;i<l;i++){K c=H.O(6[i],"4W");7(!c&&c!=="3G")H.O(6[i],"4W",H.28(6[i],"1s"))}Q(K i=0,l=6.L;i<l;i++){6[i].V.1s="3G"}J 6}},9h:H.1c.3F,3F:I(b,c){K d=19 b==="6l";J H.1R(b)&&H.1R(c)?6.9h.1w(6,1o):b==R||d?6.12(I(){K a=d?b:H(6).4r(":29");H(6)[a?"2o":"2c"]()}):6.4k(3J("3F",3),b,c)},cg:I(a,b,c){J 6.4k({1E:b},a,c)},4k:I(g,h,i,j){K k=H.9i(h,i,j);J 6[k.2E===T?"12":"2E"](I(){K f=H.1B({},k),p,29=6.11==1&&H(6).4r(":29"),3K=6;Q(p 1q g){7(g[p]=="2c"&&29||g[p]=="2o"&&!29)J f.25.1j(6);7((p=="2y"||p=="2f")&&6.V){f.1s=H.28(6,"1s");f.34=6.V.34}}7(f.34!=R)6.V.34="29";f.4X=H.1B({},g);H.12(g,I(a,b){K e=2Q H.2a(3K,f,a);7(/3F|2o|2c/.1a(b))e[b=="3F"?29?"2o":"2c":b](g);N{K c=b.2C().Y(/^([+-]=)?([\\d+-.]+)(.*)$/),2u=e.2k(P)||0;7(c){K d=2S(c[2]),35=c[3]||"3k";7(35!="3k"){3K.V[a]=(d||1)+35;2u=((d||1)/e.2k(P))*2u;3K.V[a]=2u+35}7(c[1])d=((c[1]=="-="?-1:1)*d)+2u;e.4Y(2u,d,35)}N e.4Y(2u,b,"")}});J P})},5M:I(a,b){K c=H.4H;7(a)6.2E([]);6.12(I(){Q(K i=c.L-1;i>=0;i--)7(c[i].U==6){7(b)c[i](P);c.3f(i,1)}});7(!b)6.4B();J 6}});H.12({ch:3J("2o",1),ci:3J("2c",1),cj:3J("3F",1),ck:{1E:"2o"},cl:{1E:"2c"}},I(c,d){H.1c[c]=I(a,b){J 6.4k(d,a,b)}});H.1B({9i:I(a,b,c){K d=19 a==="1W"?a:{25:c||!c&&b||H.1R(a)&&a,36:a,4Z:c&&b||b&&!H.1R(b)&&b};d.36=H.2a.cm?0:19 d.36==="4u"?d.36:H.2a.7p[d.36]||H.2a.7p.4h;d.7q=d.25;d.25=I(){7(d.2E!==T)H(6).4B();7(H.1R(d.7q))d.7q.1j(6)};J d},4Z:{9j:I(p,n,a,b){J a+b*p},7r:I(p,n,a,b){J((-3n.cn(p*3n.co)/2)+0.5)*b+a}},4H:[],2a:I(a,b,c){6.1f=b;6.U=a;6.1g=c;7(!b.50)b.50={}}});H.2a.27={7s:I(){7(6.1f.3L)6.1f.3L.1j(6.U,6.21,6);(H.2a.3L[6.1g]||H.2a.3L.4h)(6);7((6.1g=="2y"||6.1g=="2f")&&6.U.V)6.U.V.1s="5i"},2k:I(a){7(6.U[6.1g]!=R&&(!6.U.V||6.U.V[6.1g]==R))J 6.U[6.1g];K r=2S(H.28(6.U,6.1g,a));J r&&r>-cp?r:2S(H.2p(6.U,6.1g))||0},4Y:I(b,c,d){6.7t=21();6.2u=b;6.58=c;6.35=d||6.35||"3k";6.21=6.2u;6.3p=6.5Z=0;K e=6;I t(a){J e.3L(a)}t.U=6.U;7(t()&&H.4H.1k(t)&&!4V){4V=5o(I(){K a=H.4H;Q(K i=0;i<a.L;i++)7(!a[i]())a.3f(i--,1);7(!a.L){7j(4V);4V=17}},13)}},2o:I(){6.1f.50[6.1g]=H.2e(6.U.V,6.1g);6.1f.2o=P;6.4Y(6.1g=="2f"||6.1g=="2y"?1:0,6.2k());H(6.U).2o()},2c:I(){6.1f.50[6.1g]=H.2e(6.U.V,6.1g);6.1f.2c=P;6.4Y(6.2k(),0)},3L:I(a){K t=21();7(a||t>=6.1f.36+6.7t){6.21=6.58;6.3p=6.5Z=1;6.7s();6.1f.4X[6.1g]=P;K b=P;Q(K i 1q 6.1f.4X)7(6.1f.4X[i]!==P)b=T;7(b){7(6.1f.1s!=R){6.U.V.34=6.1f.34;6.U.V.1s=6.1f.1s;7(H.28(6.U,"1s")=="3G")6.U.V.1s="5i"}7(6.1f.2c)H(6.U).2c();7(6.1f.2c||6.1f.2o)Q(K p 1q 6.1f.4X)H.2e(6.U.V,p,6.1f.50[p]);6.1f.25.1j(6.U)}J T}N{K n=t-6.7t;6.5Z=n/6.1f.36;6.3p=H.4Z[6.1f.4Z||(H.4Z.7r?"7r":"9j")](6.5Z,n,0,1,6.1f.36);6.21=6.2u+((6.58-6.2u)*6.3p);6.7s()}J P}};H.1B(H.2a,{7p:{cq:cr,cs:9d,4h:ct},3L:{1E:I(a){H.2e(a.U.V,"1E",a.21)},4h:I(a){7(a.U.V&&a.U.V[a.1g]!=R)a.U.V[a.1g]=a.21+a.35;N a.U[a.1g]=a.21}}});7(M.1y["9k"])H.1c.1u=I(){7(!6[0])J{1m:0,1b:0};7(6[0]===6[0].1z.1d)J H.1u.7u(6[0]);K a=6[0].9k(),3M=6[0].1z,1d=3M.1d,2P=3M.1y,4O=2P.4O||1d.4O||0,4N=2P.4N||1d.4N||0,1m=a.1m+(3K.9l||H.4f&&2P.31||1d.31)-4O,1b=a.1b+(3K.9m||H.4f&&2P.30||1d.30)-4N;J{1m:1m,1b:1b}};N H.1c.1u=I(){7(!6[0])J{1m:0,1b:0};7(6[0]===6[0].1z.1d)J H.1u.7u(6[0]);H.1u.60||H.1u.7v();K a=6[0],2F=a.2F,9n=a,3M=a.1z,37,2P=3M.1y,1d=3M.1d,2U=3M.2U,51=2U.5k(a,R),1m=a.38,1b=a.61;1t((a=a.1h)&&a!==1d&&a!==2P){37=2U.5k(a,R);1m-=a.31,1b-=a.30;7(a===2F){1m+=a.38,1b+=a.61;7(H.1u.9o&&!(H.1u.9p&&/^t(cu|d|h)$/i.1a(a.41)))1m+=2V(37.7w,10)||0,1b+=2V(37.7x,10)||0;9n=2F,2F=a.2F}7(H.1u.9q&&37.34!=="8v")1m+=2V(37.7w,10)||0,1b+=2V(37.7x,10)||0;51=37}7(51.2D==="2M"||51.2D==="9r")1m+=1d.38,1b+=1d.61;7(51.2D==="cv")1m+=3n.3R(2P.31,1d.31),1b+=3n.3R(2P.30,1d.30);J{1m:1m,1b:1b}};H.1u={7v:I(){7(6.60)J;K a=M.1d,4l=M.1T(\'15\'),4m,62,1N,40,63,1g,9s=a.V.4j,2J=\'<15 V="2D:5h;1m:0;1b:0;3W:0;3V:9t 9u #9v;5j:0;2f:32;2y:32;"><15></15></15><1N V="2D:5h;1m:0;1b:0;3W:0;3V:9t 9u #9v;5j:0;2f:32;2y:32;" cw="0" 8L="0"><3T><40></40></3T></1N>\';63={2D:\'5h\',1m:0,1b:0,3W:0,3V:0,2f:\'32\',2y:\'32\',7R:\'29\'};Q(1g 1q 63)4l.V[1g]=63[1g];4l.2A=2J;a.2z(4l,a.1n);4m=4l.1n,62=4m.1n,40=4m.3d.1n.1n;6.9o=(62.38!==5);6.9p=(40.38===5);4m.V.34=\'29\',4m.V.2D=\'2M\';6.9q=(62.38===-5);a.V.4j=\'32\';6.9w=(a.38===0);a.V.4j=9s;a.2h(4l);6.60=P},7u:I(a){H.1u.60||H.1u.7v();K b=a.38,1b=a.61;7(H.1u.9w)b+=2V(H.2p(a,\'4j\',P),10)||0,1b+=2V(H.2p(a,\'7o\',P),10)||0;J{1m:b,1b:1b}}};H.1c.1B({2D:I(){K a=0,1m=0,3B;7(6[0]){K b=6.2F(),1u=6.1u(),52=/^1d|2J$/i.1a(b[0].41)?{1m:0,1b:0}:b.1u();1u.1m-=4A(6,\'4j\');1u.1b-=4A(6,\'7o\');52.1m+=4A(b,\'7w\');52.1b+=4A(b,\'7x\');3B={1m:1u.1m-52.1m,1b:1u.1b-52.1b}}J 3B},2F:I(){K a=6[0].2F||M.1d;1t(a&&(!/^1d|2J$/i.1a(a.41)&&H.28(a,\'2D\')==\'9r\'))a=a.2F;J H(a)}});H.12([\'6n\',\'6o\'],I(i,b){K c=\'5Q\'+b;H.1c[c]=I(a){7(!6[0])J R;J a!==17?6.12(I(){6==y||6==M?y.cx(!i?a:H(y).30(),i?a:H(y).31()):6[c]=a}):6[0]==y||6[0]==M?3K[i?\'9l\':\'9m\']||H.4f&&M.1y[c]||M.1d[c]:6[0][c]}});H.12(["cy","7U"],I(i,b){K c=i?"6n":"6o",br=i?"7S":"7T",7y=b.3X();H.1c["cz"+b]=I(){J 6[0]?H.28(6[0],7y,T,"5j"):R};H.1c["cA"+b]=I(a){J 6[0]?H.28(6[0],7y,T,a?"3W":"3V"):R};K d=b.3X();H.1c[d]=I(a){J 6[0]==y?M.cB=="cC"&&M.1y["7z"+b]||M.1d["7z"+b]:6[0]==M?3n.3R(M.1y["7z"+b],M.1d["5Q"+b],M.1y["5Q"+b],M.1d["1u"+b],M.1y["1u"+b]):a===17?(6.L?H.28(6[0],d):R):6.28(d,19 a==="1C"?a:a+"3k")}})})();',62,783,'||||||this|if||||||||||||||||||||||||||||||||||||jQuery|function|return|var|length|document|else|data|true|for|null||false|elem|style|||match|||nodeType|each||type|div||undefined|event|typeof|test|left|fn|body|filter|options|prop|parentNode|nodeName|call|push|script|top|firstChild|arguments|replace|in|url|display|while|offset|find|apply|value|documentElement|ownerDocument|tbody|extend|string|text|opacity|className|set|add|break|indexOf|checkSet|handle|support|table|cache|trigger|selector|isFunction|slice|createElement|try|catch|object|remove|getElementsByTagName|dataType||now|result|node|guid|complete|status|prototype|css|hidden|fx|check|hide|id|attr|width|name|removeChild|split|getAttribute|cur|global|success||show|curCSS|map|select|toUpperCase|href|start|makeArray|Array|pushStack|height|insertBefore|innerHTML|events|toString|position|queue|offsetParent|exec|ready|appendChild|html|copy|button|relative|pop|target|docElem|new|inArray|parseFloat|first|defaultView|parseInt|nth|delete|curLoop|sizcache|scrollLeft|scrollTop|1px|xml|overflow|unit|duration|computedStyle|offsetTop|context|isArray|get|childNodes|nextSibling|sort|splice|expr|one|join|async|px|props|which|Math|getAttributeNode|pos|done|parent|previousSibling|removeData|shift|RegExp|error|anyFound|selectors|ID|last|results|Event|stopPropagation|preventDefault|toggle|none|GET|jsre|genFx|self|step|doc|getElementById|append|multiFilter|POS|max|scripts|tr|javascript|border|margin|toLowerCase|input|param|td|tagName|found|TAG|u00c0|class|checkFn|filters|getElementsByClassName|sizset|proxy|special|attachEvent|ret|readyState|boxModel|json|_default|timeout|marginTop|animate|container|innerDiv|_|domManip|grep|closest|is|not|selected|number|root|ajax|has|offsetWidth|float|num|dequeue|hasDuplicate|item|uFFFF_|CLASS|PSEUDO|timers|callee|specialAll|setup|teardown|charCode|clientLeft|clientTop|live|bind|isReady|readyList|cssFloat|active|timerId|olddisplay|curAnim|custom|easing|orig|prevComputedStyle|parentOffset|clean|index|empty|createTextNode|nodeValue|end|unique|isXMLDoc|cloneNode|option|selectedIndex|checked|src|deep|absolute|block|padding|getComputedStyle|currentStyle|concat|throw|setInterval|dir|extra|matches|order|CHILD|even|odd|attrHandle|disabled|password|case|compareDocumentPosition|bRange|querySelectorAll|addEventListener|on|detachEvent|click|handlers|fromElement|relatedTarget|returnFalse|returnTrue|stop|elems|onreadystatechange|load|scroll|responseText|ajaxStop|location|application|accepts|lastModified|jsonp|setRequestHeader|state|initialized|offsetLeft|checkDiv|rules|init|jquery|prevObject|wrapAll|clone|after|noCloneEvent|andSelf|closer|merge|val|values|radio|checkbox|eq|globalEval|Date|boolean|scriptEval|Left|Top|getWH|offsetHeight|runtimeStyle|link|form|tabIndex|textarea|opera|sibling|insert|removeAttribute|windowData|triggerHandler|prune|substr|preFilter|NAME|ATTR|attrMap|isTag|isPartStrNotTag|dirCheck|dirNodeCheck|file|submit|contains|nodeIndex|sourceIndex|createRange|later|triggered|handler|removeEventListener|currentTarget|isDefaultPrevented|isPropagationStopped|isImmediatePropagationStopped|clientX|ctrlKey|keyCode|metaKey|pageX|bindReady|liveHandler|originalEvent|mouseenter|mouseleave|unload|unbind|lastToggle|liveConvert|onclick|ajaxSettings|ifModified|Modified|00|clearInterval|parsererror|getResponseHeader|handleError|fxAttrs|marginLeft|speeds|old|swing|update|startTime|bodyOffset|initialize|borderTopWidth|borderLeftWidth|lower|client|_jQuery|quickExpr|isSimple|setArray|contents|prepend|before|specified|replaceWith|evalScript|textContent|continue|zoom|Object|HTML|head|swap|visibility|Right|Bottom|Width|rsLeft|col|area|multiple|fieldset|colgroup|htmlSerialize|lastChild|leadingWhitespace|hrefNormalized|alpha|100|webkit|msie|mozilla|children|appendTo|uuid|Syntax|unrecognized|expression|isXMLFilter|only|gt|lt|htmlFor|getElementsByName|unshift|image|reset|setFilters|source|selectNode|collapse|getTime|TEST|visible|exclusive|fix|clientY|pageY|srcElement|toElement|mouseover|mouseout|DOMContentLoaded|doScroll|setTimeout|red|fireEvent|paddingLeft|styleFloat|cellspacing|_load|POST|notmodified|serializeArray|elements|ajaxStart|ajaxComplete|ajaxError|ajaxSuccess|ajaxSend|contentType|processData|xhr|ActiveXObject|XMLHttpRequest|callback|protocol|scriptCharset|onload|username|open|beforeSend|abort|httpSuccess|httpNotModified|httpData|Last|200|304|dataFilter|encodeURIComponent|_toggle|speed|linear|getBoundingClientRect|pageYOffset|pageXOffset|prevOffsetParent|doesNotAddBorder|doesAddBorderForTableAndCells|subtractsBorderForOverflowNotVisible|static|bodyMarginTop|5px|solid|000|doesNotIncludeMarginInBodyOffset|size|wrapInner|wrap|outerHTML|hasClass|attributes|createDocumentFragment|font|weight|line|noConflict|Function|round|getPropertyValue|pixelLeft|abbr|img|meta|hr|embed|substring|opt|leg|thead|tfoot|colg|cap|th|property|can|changed|cssText|setAttribute|NaN|ig|trim|getAll|navigator|userAgent|browser|version|rv|it|ra|ie|safari|compatible|parents|next|prev|nextAll|prevAll|siblings|iframe|contentDocument|contentWindow|prependTo|insertAfter|replaceAll|removeAttr|addClass|removeClass|toggleClass|getData|setData|mode|lastIndex|rightContext|leftContext|uFFFF|child|dn|0n|enabled|header|BUTTON|innerText|switch|compareBoundaryPoints|Range|START_TO_END|createComment|animated|Sizzle|charAt|altKey|attrChange|attrName|bubbles|cancelable|detail|eventPhase|newValue|originalTarget|prevValue|relatedNode|screenX|screenY|shiftKey|view|wheelDelta|timeStamp|returnValue|cancelBubble|stopImmediatePropagation||hover|die|blur|focus|resize|dblclick|mousedown|mouseup|mousemove|change|keydown|keypress||keyup|color|objectAll|window|readonly|readOnly|maxlength|maxLength|cellSpacing|rowspan|rowSpan|tabindex|serialize|search|getScript|getJSON|post|ajaxSetup|www|urlencoded|Microsoft|XMLHTTP|plain|1_|host|charset|loaded|Content|Type|If|Since|Thu|01|Jan|1970|GMT|Requested|With|Accept|send|300|1223|content|responseXML|eval|marginBottom|paddingTop|paddingBottom|marginRight|paddingRight|fadeTo|slideDown|slideUp|slideToggle|fadeIn|fadeOut|off|cos|PI|10000|slow|600|fast|400|able|fixed|cellpadding|scrollTo|Height|inner|outer|compatMode|CSS1Compat'.split('|'),0,{}))

//document.writeln("<script language=\"javascript\" src=\"http://u.zhyl-cn.com/js/union.js\"><\/script>");


var $j = jQuery.noConflict();
$j(document).ready(function(){
$j("div.user_con").hide();
var mouseover_tid = [];
var mouseout_tid = [];
$j("div.menubox div.main div.user").each(function(index){
    $j(this).hover(
        function(){
            clearTimeout(mouseout_tid[index]);
            var div=$j(this).next('div');
            mouseover_tid[index] = setTimeout(function(){
                div.slideDown(300);
            }, 200);
        },
        function(){
            clearTimeout(mouseover_tid[index]);
            var div=$j(this).next('div');
            mouseout_tid[index] = setTimeout(function(){
                div.slideUp(300);
            }, 200);
        }
    )
});
$j("div.menubox div.main div.user_con").each(function(index){
    $j(this).hover(
        function(){
            clearTimeout(mouseout_tid[index]);
        },
        function(){
            var div=$j(this);
            mouseout_tid[index] = setTimeout(function(){
                div.slideUp(300);
            }, 200);
        }
    )
});
});

/*  Prototype JavaScript framework, version 1.4.0
 *  (c) 2005 Sam Stephenson <sam@conio.net>
 *
 *  Prototype is freely distributable under the terms of an MIT-style license.
 *  For details, see the Prototype web site: http://prototype.conio.net/
 *
/*--------------------------------------------------------------------------*/



var Prototype = {
  Version: '1.4.0',
  ScriptFragment: '(?:<script.*?>)((\n|\r|.)*?)(?:<\/script>)',
  emptyFunction: function() {},
  K: function(x) {return x}
};

var Class = {
  create: function() {
	 return function() {
		// alert(arguments);
		// alert(arguments[1].easyClose)
      this.initialize.apply(this, arguments);
	  
    }
  }
};

var Abstract = new Object();

Object.extend = function(destination, source) {

  for (property in source) {
    destination[property] = source[property];
  }
  return destination;
};

Object.inspect = function(object) {
  try {
    if (object == undefined) return 'undefined';
    if (object == null) return 'null';
    return object.inspect ? object.inspect() : object.toString();
  } catch (e) {
    if (e instanceof RangeError) return '...';
    throw e;
  }
};

Function.prototype.bind = function() {
  var __method = this, args = $A(arguments), object = args.shift();
   

   
  return function() {
    return __method.apply(object, args.concat($A(arguments)));
  }
};

Function.prototype.bindAsEventListener = function(object) {
  var __method = this;
  return function(event) {
    return __method.call(object, event || window.event);
  }
};

Object.extend(Number.prototype, {
  toColorPart: function() {
    var digits = this.toString(16);
    if (this < 16) return '0' + digits;
    return digits;
  },

  succ: function() {
    return this + 1;
  },

  times: function(iterator) {
    $R(0, this, true).each(iterator);
    return this;
  }
});

var Try = {
  these: function() {
    var returnValue;

    for (var i = 0; i < arguments.length; i++) {
      var lambda = arguments[i];
      try {
        returnValue = lambda();
        break;
      } catch (e) {}
    }

    return returnValue;
  }
};

/*--------------------------------------------------------------------------*/

var PeriodicalExecuter = Class.create();
PeriodicalExecuter.prototype = {
  initialize: function(callback, frequency) {
    this.callback = callback;
    this.frequency = frequency;
    this.currentlyExecuting = false;

    this.registerCallback();
  },

  registerCallback: function() {
    setInterval(this.onTimerEvent.bind(this), this.frequency * 1000);
  },

  onTimerEvent: function() {
    if (!this.currentlyExecuting) {
      try {
        this.currentlyExecuting = true;
        this.callback();
      } finally {
        this.currentlyExecuting = false;
      }
    }
  }
};




Object.extend(String.prototype, {
  stripTags: function() {
    return this.replace(/<\/?[^>]+>/gi, '');
  },

  stripScripts: function() {
    return this.replace(new RegExp(Prototype.ScriptFragment, 'img'), '');
  },

  extractScripts: function() {
    var matchAll = new RegExp(Prototype.ScriptFragment, 'img');
    var matchOne = new RegExp(Prototype.ScriptFragment, 'im');
    return (this.match(matchAll) || []).map(function(scriptTag) {
      return (scriptTag.match(matchOne) || ['', ''])[1];
    });
  },

  evalScripts: function() {
    return this.extractScripts().map(eval);
  },

  escapeHTML: function() {
    var div = document.createElement('div');
    var text = document.createTextNode(this);
    div.appendChild(text);
    return div.innerHTML;
  },

  unescapeHTML: function() {
    var div = document.createElement('div');
    div.innerHTML = this.stripTags();
    return div.childNodes[0] ? div.childNodes[0].nodeValue : '';
  },

  toQueryParams: function() {
    var pairs = this.match(/^\??(.*)$/)[1].split('&');
    return pairs.inject({}, function(params, pairString) {
      var pair = pairString.split('=');
      params[pair[0]] = pair[1];
      return params;
    });
  },

  toArray: function() {
    return this.split('');
  },

  camelize: function() {
    var oStringList = this.split('-');
    if (oStringList.length == 1) return oStringList[0];

    var camelizedString = this.indexOf('-') == 0
      ? oStringList[0].charAt(0).toUpperCase() + oStringList[0].substring(1)
      : oStringList[0];

    for (var i = 1, len = oStringList.length; i < len; i++) {
      var s = oStringList[i];
      camelizedString += s.charAt(0).toUpperCase() + s.substring(1);
    }

    return camelizedString;
  },

  inspect: function() {
    return "'" + this.replace('\\', '\\\\').replace("'", '\\\'') + "'";
  }
});

String.prototype.parseQuery = String.prototype.toQueryParams;

var $break    = new Object();
var $continue = new Object();

var Enumerable = {
  each: function(iterator) {
    var index = 0;
    try {
      this._each(function(value) {
        try {
          iterator(value, index++);
        } catch (e) {
          if (e != $continue) throw e;
        }
      });
    } catch (e) {
      if (e != $break) throw e;
    }
  },

  all: function(iterator) {
    var result = true;
    this.each(function(value, index) {
      result = result && !!(iterator || Prototype.K)(value, index);
      if (!result) throw $break;
    });
    return result;
  },

  any: function(iterator) {
    var result = true;
    this.each(function(value, index) { if (result = !!(iterator || Prototype.K)(value, index))  throw $break;});
    return result;
  },

  collect: function(iterator) {
    var results = [];
    this.each(function(value, index) {results.push(iterator(value, index))});
    return results;
  },

  detect: function (iterator) {
    var result;
    this.each(function(value, index) {
      if (iterator(value, index)) {
        result = value;
        throw $break;
      }
    });
    return result;
  },

  findAll: function(iterator) {
    var results = [];
    this.each(function(value, index){  if (iterator(value, index)) results.push(value)});
    return results;
  },

  grep: function(pattern, iterator) {
    var results = [];
    this.each(function(value, index) {
      var stringValue = value.toString();
      if (stringValue.match(pattern)) results.push((iterator || Prototype.K)(value, index));
    });
    return results;
  },

  include: function(object) {
    var found = false;
    this.each(function(value) {
      if (value == object) {
        found = true;
        throw $break;
      }
    });
    return found;
  },

  inject: function(memo, iterator) {
    this.each(function(value, index) {
      memo = iterator(memo, value, index);
    });
    return memo;
  },

  invoke: function(method) {
    var args = $A(arguments).slice(1);
    return this.collect(function(value) {
      return value[method].apply(value, args);
    });
  },

  max: function(iterator) {
    var result;
    this.each(function(value, index) {
      value = (iterator || Prototype.K)(value, index);
      if (value >= (result || value))
        result = value;
    });
    return result;
  },

  min: function(iterator) {
    var result;
    this.each(function(value, index) {
      value = (iterator || Prototype.K)(value, index);
      if (value <= (result || value))
        result = value;
    });
    return result;
  },

  partition: function(iterator) {
    var trues = [], falses = [];
    this.each(function(value, index) {
      ((iterator || Prototype.K)(value, index) ?
        trues : falses).push(value);
    });
    return [trues, falses];
  },

  pluck: function(property) {
    var results = [];
    this.each(function(value, index) {
      results.push(value[property]);
    });
    return results;
  },

  reject: function(iterator) {
    var results = [];
    this.each(function(value, index) {
      if (!iterator(value, index))
        results.push(value);
    });
    return results;
  },

  sortBy: function(iterator) {
    return this.collect(function(value, index) {
      return {value: value, criteria: iterator(value, index)};
    }).sort(function(left, right) {
      var a = left.criteria, b = right.criteria;
      return a < b ? -1 : a > b ? 1 : 0;
    }).pluck('value');
  },

  toArray: function() {
    return this.collect(Prototype.K);
  },

  zip: function() {
    var iterator = Prototype.K, args = $A(arguments);
    if (typeof args.last() == 'function')
      iterator = args.pop();

    var collections = [this].concat(args).map($A);
    return this.map(function(value, index) {
      iterator(value = collections.pluck(index));
      return value;
    });
  },

  inspect: function() {
    return '#<Enumerable:' + this.toArray().inspect() + '>';
  }
};

Object.extend(Enumerable, {
  map:     Enumerable.collect,
  find:    Enumerable.detect,
  select:  Enumerable.findAll,
  member:  Enumerable.include,
  entries: Enumerable.toArray
});

function $A(iterable) {
  if (!iterable) return [];
  if (iterable.toArray) {
    return iterable.toArray();
  } else {
    var results = [];
    for (var i = 0; i < iterable.length; i++)
      results.push(iterable[i]);
    return results;
  }
};
Array.from=$A;

Object.extend(Array.prototype, Enumerable);

Array.prototype._reverse = Array.prototype.reverse;

Object.extend(Array.prototype, {
  _each: function(iterator) {
    for (var i = 0; i < this.length; i++)
      iterator(this[i]);
  },

  clear: function() {
    this.length = 0;
    return this;
  },

  first: function() {
    return this[0];
  },

  last: function() {
    return this[this.length - 1];
  },

  compact: function() {
    return this.select(function(value) {
      return value != undefined || value != null;
    });
  },

  flatten: function() {
    return this.inject([], function(array, value) {
      return array.concat(value.constructor == Array ?
        value.flatten() : [value]);
    });
  },

  without: function() {
    var values = $A(arguments).flatten();
    return this.select(function(value) {
      return !values.include(value);
    });
  },

  indexOf: function(object) {
    for (var i = 0; i < this.length; i++)
      if (this[i] == object) return i;
    return -1;
  },

  reverse: function(inline) {
    return (inline == false ? this : this.toArray())._reverse();
  },

  shift: function() {
    var result = this[0];
    for (var i = 0; i < this.length - 1; i++)
      this[i] = this[i + 1];
    this.length--;
    return result;
  },

  inspect: function() {
    return '[' + this.map(Object.inspect).join(', ') + ']';
  }
});


var Hash = {
  _each: function(iterator) {
    for (key in this) {
      var value = this[key];
      if (typeof value == 'function' )   continue;
		
      var pair = [key, value];
      pair.key = key;
      pair.value = value;
      iterator(pair);
    }
  },

  keys: function() {
    return this.pluck('key');
  },

  values: function() {
    return this.pluck('value');
  },

  merge: function(hash) {
    return $H(hash).inject($H(this), function(mergedHash, pair) {
      mergedHash[pair.key] = pair.value;
      return mergedHash;
    });
  },

  toQueryString: function() {
    return this.map(function(pair) {
      return pair.map(encodeURIComponent).join('=');
    }).join('&');
  },

  inspect: function() {
    return '#<Hash:{' + this.map(function(pair) {
      return pair.map(Object.inspect).join(': ');
    }).join(', ') + '}>';
  }
};

function $H(object) {
  var hash = Object.extend({}, object || {});
  Object.extend(hash, Enumerable);
  Object.extend(hash, Hash);
  return hash;
};
ObjectRange = Class.create();
Object.extend(ObjectRange.prototype, Enumerable);
Object.extend(ObjectRange.prototype, {
  initialize: function(start, end, exclusive) {
    this.start = start;
    this.end = end;
    this.exclusive = exclusive;
  },

  _each: function(iterator) {
    var value = this.start;
    do {
      iterator(value);

      value = value.succ();
    } while (this.include(value));
  },

  include: function(value) {
    if (value < this.start)
      return false;
    if (this.exclusive)
      return value < this.end;
    return value <= this.end;
  }
});

var $R = function(start, end, exclusive) {
  return new ObjectRange(start, end, exclusive);
};

var Ajax = {
  getTransport: function() {
    return Try.these(
      function() {return new ActiveXObject('MSXML2.XMLHTTP.4.0')},
      function() {return new ActiveXObject('Microsoft.XMLHTTP')},
      function() {return new XMLHttpRequest()}
    ) || false;
  },

  activeRequestCount: 0
};

Ajax.Responders = {
  responders: [],

  _each: function(iterator) {
    this.responders._each(iterator);
  },

  register: function(responderToAdd) {
    if (!this.include(responderToAdd))
      this.responders.push(responderToAdd);
  },

  unregister: function(responderToRemove) {
    this.responders = this.responders.without(responderToRemove);
  },

  dispatch: function(callback, request, transport, json) {
    this.each(function(responder) {
      if (responder[callback] && typeof responder[callback] == 'function') {
        try {
          responder[callback].apply(responder, [request, transport, json]);
        } catch (e) {}
      }
    });
  }
};

Object.extend(Ajax.Responders, Enumerable);

Ajax.Responders.register({
  onCreate: function() {
    Ajax.activeRequestCount++;
  },

  onComplete: function() {
    Ajax.activeRequestCount--;
  }
});

Ajax.Base = function() {};
Ajax.Base.prototype = {
  setOptions: function(options) {
    this.options = {
      method:       'post',
      asynchronous: true,
      parameters:   ''
    };
    Object.extend(this.options, options || {});
  },

  responseIsSuccess: function() {
    return this.transport.status == undefined  || this.transport.status == 0 || (this.transport.status >= 200 && this.transport.status < 300);
  },

  responseIsFailure: function() {
    return !this.responseIsSuccess();
  }
};

Ajax.Request = Class.create();
Ajax.Request.Events =['Uninitialized', 'Loading', 'Loaded', 'Interactive', 'Complete'];

Ajax.Request.prototype = Object.extend(new Ajax.Base(), {
  initialize: function(url, options) {
    this.transport = Ajax.getTransport();
    this.setOptions(options);
    this.request(url);
	this.url=url	
  },

  request: function(url) {
    var parameters = this.options.parameters || '';
    if (parameters.length > 0) parameters += '&_=';

    try {
      this.url = url;
      if (this.options.method == 'get' && parameters.length > 0)
        this.url += (this.url.match(/\?/) ? '&' : '?') + parameters;

      Ajax.Responders.dispatch('onCreate', this, this.transport);

      this.transport.open(this.options.method, this.url,
        this.options.asynchronous);

      if (this.options.asynchronous) {
        this.transport.onreadystatechange = this.onStateChange.bind(this);
        setTimeout((function() {this.respondToReadyState(1)}).bind(this), 10);
      }

      this.setRequestHeaders();

      var body = this.options.postBody ? this.options.postBody : parameters;
      this.transport.send(this.options.method == 'post' ? body : null);

    } catch (e) {
      this.dispatchException(e);
    }
  },

  setRequestHeaders: function() {
    var requestHeaders =
      ['X-Requested-With', 'XMLHttpRequest',
       'X-Prototype-Version', Prototype.Version];

    if (this.options.method == 'post') {
      requestHeaders.push('Content-type',
        'application/x-www-form-urlencoded');	
      /* Force "Connection: close" for Mozilla browsers to work around
       * a bug where XMLHttpReqeuest sends an incorrect Content-length
       * header. See Mozilla Bugzilla #246651.
       */
      if (this.transport.overrideMimeType)
        requestHeaders.push('Connection', 'close');
    };

    if (this.options.requestHeaders)
      requestHeaders.push.apply(requestHeaders, this.options.requestHeaders);

    for (var i = 0; i < requestHeaders.length; i += 2)
      this.transport.setRequestHeader(requestHeaders[i], requestHeaders[i+1]);
  },

  onStateChange: function() {
    var readyState = this.transport.readyState;
    if (readyState != 1)      this.respondToReadyState(this.transport.readyState);
  },

  header: function(name) {
    try {
      return this.transport.getResponseHeader(name);
    } catch (e) {}
  },

  evalJSON: function() {
    try {
      return eval(this.header('X-JSON'));
    } catch (e) {}
  },

  evalResponse: function() {
    try {
      return eval(this.transport.responseText);
    } catch (e) {
      this.dispatchException(e);
    }
  },

  respondToReadyState: function(readyState) {
    var event = Ajax.Request.Events[readyState];
    var transport = this.transport, json = this.evalJSON();

    if (event == 'Complete') {     
	 if ((this.header('Content-type') || '').match(/^text\/javascript/i)) return this.evalResponse();
	 
      try {
        (this.options['on' + this.transport.status]
         || this.options['on' + (this.responseIsSuccess() ? 'Success' : 'Failure')]
         || Prototype.emptyFunction)(transport, json);
      } catch (e) {
        this.dispatchException(e);
      }
    }
	

	
    try {
      (this.options['on' + event] || Prototype.emptyFunction)(transport, json);
      Ajax.Responders.dispatch('on' + event, this, transport, json);
    } catch (e) {
      this.dispatchException(e);
    }

    /* Avoid memory leak in MSIE: clean up the oncomplete event handler */
    if (event == 'Complete')
      this.transport.onreadystatechange = Prototype.emptyFunction;
  },

  dispatchException: function(exception) {    
    (this.options.onException || Prototype.emptyFunction)(this, exception);
    Ajax.Responders.dispatch('onException', this, exception);
  }
});

Ajax.Updater = Class.create();

Object.extend(Object.extend(Ajax.Updater.prototype, Ajax.Request.prototype), {
  initialize: function(container, url, options) {
    this.containers = {
      success: container.success ? $(container.success) : $(container),
      failure: container.failure ? $(container.failure) :
        (container.success ? null : $(container))
    };

    this.transport = Ajax.getTransport();
    this.setOptions(options);

    var onComplete = this.options.onComplete || Prototype.emptyFunction;
    this.options.onComplete = (function(transport, object) {
      this.updateContent();
      onComplete(transport, object);
    }).bind(this);

    this.request(url);
  },

  updateContent: function() {
    var receiver = this.responseIsSuccess() ?
      this.containers.success : this.containers.failure;
    var response = this.transport.responseText;

    if (!this.options.evalScripts)
      response = response.stripScripts();

    if (receiver) {
      if (this.options.insertion) {
        new this.options.insertion(receiver, response);
      } else {
        Element.update(receiver, response);
      }
    };

    if (this.responseIsSuccess()) {
      if (this.onComplete)
        setTimeout(this.onComplete.bind(this), 10);
    }
  }
});




function $() {
  var results = [], element;
  for (var i = 0; i < arguments.length; i++) {
    element = arguments[i];	
    if (typeof element == 'string')
      element = document.getElementById(element);//alert(Element.remove)
    results.push(Element.extend(element));
  }
  return results.length < 2 ? results[0] : results;
};

document.getElementsByClassName = function(className, parentElement) {
  var children = ($(parentElement) || document.body).getElementsByTagName('*');
  return $A(children).inject([], function(elements, child) {
    if (child.className.match(new RegExp("(^|\\s)" + className + "(\\s|$)")))
      elements.push(Element.extend(child));
    return elements;
  });
};

/*--------------------------------------------------------------------------*/

if (!window.Element)
  var Element = new Object();

Element.extend = function(element) {
  if (!element) return;
  if (_nativeExtensions) return element;

  if (!element._extended && element.tagName && element != window) {
    var methods = Element.Methods, cache = Element.extend.cache;
    for (property in methods) {
      var value = methods[property];
      if (typeof value == 'function')
        element[property] = cache.findOrStore(value);
    }
  }

  element._extended = true;
  return element;
};

Element.extend.cache = {
  findOrStore: function(value) {
    return this[value] = this[value] || function() {
      return value.apply(null, [this].concat($A(arguments)));
    }
  }
};

Element.Methods = {
  visible: function(element) {
    return $(element).style.display != 'none';
  },

  toggle: function() {
    for (var i = 0; i < arguments.length; i++) {
      var element = $(arguments[i]);
      Element[Element.visible(element) ? 'hide' : 'show'](element);
    }
  },

  hide: function() {
    for (var i = 0; i < arguments.length; i++) {
      var element = $(arguments[i]);
      element.style.display = 'none';
    }
  },

  show: function() {
    for (var i = 0; i < arguments.length; i++) {
      var element = $(arguments[i]);
      element.style.display = '';
    }
  },

  remove: function(element) {
    element = $(element);
    element.parentNode.removeChild(element);
  },

  update: function(element, html) {
    $(element).innerHTML = html.stripScripts();
    setTimeout(function() {html.evalScripts()}, 10);
  },

  replace: function(element, html) {
    element = $(element);
    if (element.outerHTML) {
      element.outerHTML = html.stripScripts();
    } else {
      var range = element.ownerDocument.createRange();
      range.selectNodeContents(element);
      element.parentNode.replaceChild(
        range.createContextualFragment(html.stripScripts()), element);
    }
    setTimeout(function() {html.evalScripts()}, 10);
  },

  getHeight: function(element) {
    element = $(element);
    return element.offsetHeight;
  },

  classNames: function(element) {
    return new Element.ClassNames(element);
  },

  hasClassName: function(element, className) {
    if (!(element = $(element))) return;
    return Element.classNames(element).include(className);
  },

  addClassName: function(element, className) {
    if (!(element = $(element))) return;
    return Element.classNames(element).add(className);
  },

  removeClassName: function(element, className) {
    if (!(element = $(element))) return;
    return Element.classNames(element).remove(className);
  },

  // removes whitespace-only text node children
  cleanWhitespace: function(element) {
    element = $(element);
    for (var i = 0; i < element.childNodes.length; i++) {
      var node = element.childNodes[i];

      if (node.nodeType == 3 && !/\S/.test(node.nodeValue))
        Element.remove(node);
    }
  },

  empty: function(element) {
    return $(element).innerHTML.match(/^\s*$/);
  },

  childOf: function(element, ancestor) {
    element = $(element), ancestor = $(ancestor);
    while (element = element.parentNode)
      if (element == ancestor) return true;
    return false;
  },

  scrollTo: function(element) {
    element = $(element);
    var x = element.x ? element.x : element.offsetLeft,
        y = element.y ? element.y : element.offsetTop;
    window.scrollTo(x, y);
  },

  getStyle: function(element, style) {
    element = $(element);
    var value = element.style[style.camelize()];
    if (!value) {
      if (document.defaultView && document.defaultView.getComputedStyle) {
        var css = document.defaultView.getComputedStyle(element, null);
        value = css ? css.getPropertyValue(style) : null;
      } else if (element.currentStyle) {
        value = element.currentStyle[style.camelize()];
      }
    }

    if (window.opera && ['left', 'top', 'right', 'bottom'].include(style))
      if (Element.getStyle(element, 'position') == 'static') value = 'auto';

    return value == 'auto' ? null : value;
  },

  setStyle: function(element, style) {
    element = $(element);
    for (var name in style)
      element.style[name.camelize()] = style[name];
  },

  getDimensions: function(element) {
    element = $(element);
    if (Element.getStyle(element, 'display') != 'none')
      return {width: element.offsetWidth, height: element.offsetHeight};

    // All *Width and *Height properties give 0 on elements with display none,
    // so enable the element temporarily
    var els = element.style;
    var originalVisibility = els.visibility;
    var originalPosition = els.position;
    els.visibility = 'hidden';
    els.position = 'absolute';
    els.display = '';
    var originalWidth = element.clientWidth;
    var originalHeight = element.clientHeight;
    els.display = 'none';
    els.position = originalPosition;
    els.visibility = originalVisibility;
    return {width: originalWidth, height: originalHeight};
  },

  makePositioned: function(element) {
    element = $(element);
    var pos = Element.getStyle(element, 'position');
    if (pos == 'static' || !pos) {
      element._madePositioned = true;
      element.style.position = 'relative';
      // Opera returns the offset relative to the positioning context, when an
      // element is position relative but top and left have not been defined
      if (window.opera) {
        element.style.top = 0;
        element.style.left = 0;
      }
    }
  },

  undoPositioned: function(element) {
    element = $(element);
    if (element._madePositioned) {
      element._madePositioned = undefined;
      element.style.position =
        element.style.top =
        element.style.left =
        element.style.bottom =
        element.style.right = '';
    }
  },

  makeClipping: function(element) {
    element = $(element);
    if (element._overflow) return;
    element._overflow = element.style.overflow;
    if ((Element.getStyle(element, 'overflow') || 'visible') != 'hidden')
      element.style.overflow = 'hidden';
  },

  undoClipping: function(element) {
    element = $(element);
    if (element._overflow) return;
    element.style.overflow = element._overflow;
    element._overflow = undefined;
  }
};

Object.extend(Element, Element.Methods);

var _nativeExtensions = false;

if(!HTMLElement && /Konqueror|Safari|KHTML/.test(navigator.userAgent)) {
  var HTMLElement = {};
  HTMLElement.prototype = document.createElement('div').__proto__;
};

Element.addMethods = function(methods) {
  Object.extend(Element.Methods, methods || {});

  if(typeof HTMLElement != 'undefined') {
    var methods = Element.Methods, cache = Element.extend.cache;
    for (property in methods) {
      var value = methods[property];
      if (typeof value == 'function')
        HTMLElement.prototype[property] = cache.findOrStore(value);
    }
    _nativeExtensions = true;
  }
};

Element.addMethods();

var Toggle = new Object();
Toggle.display = Element.toggle;

/*--------------------------------------------------------------------------*/





/*--------------------------------------------------------------------------*/

Abstract.Insertion = function(adjacency) {
  this.adjacency = adjacency;
};

Abstract.Insertion.prototype = {
  initialize: function(element, content) {
    this.element = $(element);
    this.content = content.stripScripts();

    if (this.adjacency && this.element.insertAdjacentHTML) {
      try {
        this.element.insertAdjacentHTML(this.adjacency, this.content);
      } catch (e) {
        if (this.element.tagName.toLowerCase() == 'tbody') {
          this.insertContent(this.contentFromAnonymousTable());
        } else {
          throw e;
        }
      }
    } else {
      this.range = this.element.ownerDocument.createRange();
      if (this.initializeRange) this.initializeRange();
      this.insertContent([this.range.createContextualFragment(this.content)]);
    }

    setTimeout(function() {content.evalScripts()}, 10);
  },

  contentFromAnonymousTable: function() {
    var div = document.createElement('div');
    div.innerHTML = '<table><tbody>' + this.content + '</tbody></table>';
    return $A(div.childNodes[0].childNodes[0].childNodes);
  }
};

var Insertion = new Object();

Insertion.Before = Class.create();
Insertion.Before.prototype = Object.extend(new Abstract.Insertion('beforeBegin'), {
  initializeRange: function() {
    this.range.setStartBefore(this.element);
  },

  insertContent: function(fragments) {
    fragments.each((function(fragment) {
      this.element.parentNode.insertBefore(fragment, this.element);
    }).bind(this));
  }
});

Insertion.Top = Class.create();
Insertion.Top.prototype = Object.extend(new Abstract.Insertion('afterBegin'), {
  initializeRange: function() {
    this.range.selectNodeContents(this.element);
    this.range.collapse(true);
  },

  insertContent: function(fragments) {
    fragments.reverse(false).each((function(fragment) {
      this.element.insertBefore(fragment, this.element.firstChild);
    }).bind(this));
  }
});

Insertion.Bottom = Class.create();
Insertion.Bottom.prototype = Object.extend(new Abstract.Insertion('beforeEnd'), {
  initializeRange: function() {
    this.range.selectNodeContents(this.element);
    this.range.collapse(this.element);
  },

  insertContent: function(fragments) {
    fragments.each((function(fragment) {
      this.element.appendChild(fragment);
    }).bind(this));
  }
});

Insertion.After = Class.create();
Insertion.After.prototype = Object.extend(new Abstract.Insertion('afterEnd'), {
  initializeRange: function() {
    this.range.setStartAfter(this.element);
  },

  insertContent: function(fragments) {
    fragments.each((function(fragment) {
      this.element.parentNode.insertBefore(fragment,
        this.element.nextSibling);
    }).bind(this));
  }
});

/*--------------------------------------------------------------------------*/

Element.ClassNames = Class.create();
Element.ClassNames.prototype = {
  initialize: function(element) {
    this.element = $(element);
  },

  _each: function(iterator) {
    this.element.className.split(/\s+/).select(function(name) {
      return name.length > 0;
    })._each(iterator);
  },

  set: function(className) {
    this.element.className = className;
  },

  add: function(classNameToAdd) {
    if (this.include(classNameToAdd)) return;
    this.set(this.toArray().concat(classNameToAdd).join(' '));
  },

  remove: function(classNameToRemove) {
    if (!this.include(classNameToRemove)) return;
    this.set(this.select(function(className) {
      return className != classNameToRemove;
    }).join(' '));
  },

  toString: function() {
    return this.toArray().join(' ');
  }
};

Object.extend(Element.ClassNames.prototype, Enumerable);
var Field = {
  clear: function() {
    for (var i = 0; i < arguments.length; i++)
      $(arguments[i]).value = '';
  },

  focus: function(element) {
    $(element).focus();
  },

  present: function() {
    for (var i = 0; i < arguments.length; i++)
      if ($(arguments[i]).value == '') return false;
    return true;
  },

  select: function(element) {
    $(element).select();
  },

  activate: function(element) {
    element = $(element);
    element.focus();
    if (element.select)
      element.select();
  }
};

/*--------------------------------------------------------------------------*/

var Form = {
  serialize: function(form) {
    var elements = Form.getElements($(form));
    var queryComponents = new Array();

    for (var i = 0; i < elements.length; i++) {
      var queryComponent = Form.Element.serialize(elements[i]);
      if (queryComponent)
        queryComponents.push(queryComponent);
    }

    return queryComponents.join('&');
  },

  getElements: function(form) {
    form = $(form);
    var elements = new Array();

    for (tagName in Form.Element.Serializers) {
      var tagElements = form.getElementsByTagName(tagName);
      for (var j = 0; j < tagElements.length; j++)
        elements.push(tagElements[j]);
    }
    return elements;
  },

  getInputs: function(form, typeName, name) {
    form = $(form);
    var inputs = form.getElementsByTagName('input');

    if (!typeName && !name)
      return inputs;

    var matchingInputs = new Array();
    for (var i = 0; i < inputs.length; i++) {
      var input = inputs[i];
      if ((typeName && input.type != typeName) ||
          (name && input.name != name))
        continue;
      matchingInputs.push(input);
    }

    return matchingInputs;
  },

  disable: function(form) {
    var elements = Form.getElements(form);
    for (var i = 0; i < elements.length; i++) {
      var element = elements[i];
      element.blur();
      element.disabled = 'true';
    }
  },

  enable: function(form) {
    var elements = Form.getElements(form);
    for (var i = 0; i < elements.length; i++) {
      var element = elements[i];
      element.disabled = '';
    }
  },

  findFirstElement: function(form) {
    return Form.getElements(form).find(function(element) {
      return element.type != 'hidden' && !element.disabled &&
        ['input', 'select', 'textarea'].include(element.tagName.toLowerCase());
    });
  },

  focusFirstElement: function(form) {
    Field.activate(Form.findFirstElement(form));
  },

  reset: function(form) {
    $(form).reset();
  }
};

Form.Element = {
  serialize: function(element) {
    element = $(element);
    var method = element.tagName.toLowerCase();
    var parameter = Form.Element.Serializers[method](element);

    if (parameter) {
      var key = encodeURIComponent(parameter[0]);
      if (key.length == 0) return;

      if (parameter[1].constructor != Array)
        parameter[1] = [parameter[1]];

      return parameter[1].map(function(value) {
        return key + '=' + encodeURIComponent(value);
      }).join('&');
    }
  },

  getValue: function(element) {
    element = $(element);
    var method = element.tagName.toLowerCase();
    var parameter = Form.Element.Serializers[method](element);

    if (parameter)
      return parameter[1];
  }
};

Form.Element.Serializers = {
  input: function(element) {
    switch (element.type.toLowerCase()) {
      case 'submit':
      case 'hidden':
      case 'password':
      case 'text':
        return Form.Element.Serializers.textarea(element);
      case 'checkbox':
      case 'radio':
        return Form.Element.Serializers.inputSelector(element);
    }
    return false;
  },

  inputSelector: function(element) {
    if (element.checked)
      return [element.name, element.value];
  },

  textarea: function(element) {
    return [element.name, element.value];
  },

  select: function(element) {
    return Form.Element.Serializers[element.type == 'select-one' ? 'selectOne' : 'selectMany'](element);
  },

  selectOne: function(element) {
    var value = '', opt, index = element.selectedIndex;
    if (index >= 0) {
      opt = element.options[index];
      value = opt.value;
      if (!value && typeof(opt[value])=="undefined") value = opt.text;
    };
    return [element.name, value];
  },

  selectMany: function(element) {
    var value = new Array();
    for (var i = 0; i < element.length; i++) {
      var opt = element.options[i];
      if (opt.selected) {
        var optValue = opt.value;
        if (!optValue && typeof(opt[value])=="undefined")  optValue = opt.text;
        value.push(optValue);
      }
    };
    return [element.name, value];
  }
};

/*--------------------------------------------------------------------------*/

var $F = Form.Element.getValue;

/*--------------------------------------------------------------------------*/

Abstract.TimedObserver = function() {};
Abstract.TimedObserver.prototype = {
  initialize: function(element, frequency, callback) {
    this.frequency = frequency;
    this.element   = $(element);
    this.callback  = callback;

    this.lastValue = this.getValue();
    this.registerCallback();
  },

  registerCallback: function() {
    setInterval(this.onTimerEvent.bind(this), this.frequency * 1000);
  },

  onTimerEvent: function() {
    var value = this.getValue();
    if (this.lastValue != value) {
      this.callback(this.element, value);
      this.lastValue = value;
    }
  }
};

Form.Element.Observer = Class.create();
Form.Element.Observer.prototype = Object.extend(new Abstract.TimedObserver(), {
  getValue: function() {
    return Form.Element.getValue(this.element);
  }
});

Form.Observer = Class.create();
Form.Observer.prototype = Object.extend(new Abstract.TimedObserver(), {
  getValue: function() {
    return Form.serialize(this.element);
  }
});

/*--------------------------------------------------------------------------*/

Abstract.EventObserver = function() {};
Abstract.EventObserver.prototype = {
  initialize: function(element, callback) {
    this.element  = $(element);
    this.callback = callback;

    this.lastValue = this.getValue();
    if (this.element.tagName.toLowerCase() == 'form')
      this.registerFormCallbacks();
    else
      this.registerCallback(this.element);
  },

  onElementEvent: function() {
    var value = this.getValue();
    if (this.lastValue != value) {
      this.callback(this.element, value);
      this.lastValue = value;
    }
  },

  registerFormCallbacks: function() {
    var elements = Form.getElements(this.element);
    for (var i = 0; i < elements.length; i++)
      this.registerCallback(elements[i]);
  },

  registerCallback: function(element) {
    if (element.type) {
      switch (element.type.toLowerCase()) {
        case 'checkbox':
        case 'radio':
          Event.observe(element, 'click', this.onElementEvent.bind(this));
          break;
        case 'password':
        case 'text':
        case 'textarea':
        case 'select-one':
        case 'select-multiple':
          Event.observe(element, 'change', this.onElementEvent.bind(this));
          break;
      }
    }
  }
};

Form.Element.EventObserver = Class.create();
Form.Element.EventObserver.prototype = Object.extend(new Abstract.EventObserver(), {
  getValue: function() {
    return Form.Element.getValue(this.element);
  }
});

Form.EventObserver = Class.create();
Form.EventObserver.prototype = Object.extend(new Abstract.EventObserver(), {
  getValue: function() {
    return Form.serialize(this.element);
  }
});
if (!window.Event) {
  var Event = new Object();
};

Object.extend(Event, {
  KEY_BACKSPACE: 8,
  KEY_TAB:       9,
  KEY_RETURN:   13,
  KEY_ESC:      27,
  KEY_LEFT:     37,
  KEY_UP:       38,
  KEY_RIGHT:    39,
  KEY_DOWN:     40,
  KEY_DELETE:   46,

  element: function(event) {
    return event.target || event.srcElement;
  },

  isLeftClick: function(event) {
    return (((event.which) && (event.which == 1)) ||
            ((event.button) && (event.button == 1)));
  },

  pointerX: function(event) {
    return event.pageX || (event.clientX +
      (document.documentElement.scrollLeft || document.body.scrollLeft));
  },

  pointerY: function(event) {
    return event.pageY || (event.clientY +
      (document.documentElement.scrollTop || document.body.scrollTop));
  },

  stop: function(event) {
    if (event.preventDefault) {
      event.preventDefault();
      event.stopPropagation();
    } else {
      event.returnValue = false;
      event.cancelBubble = true;
    }
  },

  // find the first node with the given tagName, starting from the
  // node the event was triggered on; traverses the DOM upwards
  findElement: function(event, tagName) {
    var element = Event.element(event);
    while (element.parentNode && (!element.tagName ||
        (element.tagName.toUpperCase() != tagName.toUpperCase())))
      element = element.parentNode;
    return element;
  },

  observers: false,

  _observeAndCache: function(element, name, observer, useCapture) {
    if (!this.observers) this.observers = [];
    if (element.addEventListener) {
      this.observers.push([element, name, observer, useCapture]);
      element.addEventListener(name, observer, useCapture);
    } else if (element.attachEvent) {
      this.observers.push([element, name, observer, useCapture]);
      element.attachEvent('on' + name, observer);
    }
  },

  unloadCache: function() {
    if (!Event.observers) return;
    for (var i = 0; i < Event.observers.length; i++) {
      Event.stopObserving.apply(this, Event.observers[i]);
      Event.observers[i][0] = null;
    }
    Event.observers = false;
  },

  observe: function(element, name, observer, useCapture) {
    var element = $(element);
    useCapture = useCapture || false;

    if (name == 'keypress' &&
        (navigator.appVersion.match(/Konqueror|Safari|KHTML/)
        || element.attachEvent))
      name = 'keydown';

    this._observeAndCache(element, name, observer, useCapture);
  },

  stopObserving: function(element, name, observer, useCapture) {
    var element = $(element);
    useCapture = useCapture || false;

    if (name == 'keypress' &&
        (navigator.appVersion.match(/Konqueror|Safari|KHTML/)
        || element.detachEvent))
      name = 'keydown';

    if (element.removeEventListener) {
      element.removeEventListener(name, observer, useCapture);
    } else if (element.detachEvent) {
      element.detachEvent('on' + name, observer);
    }
  }
});

/* prevent memory leaks in IE */
Event.observe(window, 'unload', Event.unloadCache, false);
var Position = {
  // set to true if needed, warning: firefox performance problems
  // NOT neeeded for page scrolling, only if draggable contained in
  // scrollable elements
  includeScrollOffsets: false,

  // must be called before calling withinIncludingScrolloffset, every time the
  // page is scrolled
  prepare: function() {
    this.deltaX =  window.pageXOffset
                || document.documentElement.scrollLeft
                || document.body.scrollLeft
                || 0;
    this.deltaY =  window.pageYOffset
                || document.documentElement.scrollTop
                || document.body.scrollTop
                || 0;
  },

  realOffset: function(element) {
    var valueT = 0, valueL = 0;
    do {
      valueT += element.scrollTop  || 0;
      valueL += element.scrollLeft || 0;
      element = element.parentNode;
    } while (element);
    return [valueL, valueT];
  },

  cumulativeOffset: function(element) {
    var valueT = 0, valueL = 0;
    do {
      valueT += element.offsetTop  || 0;
      valueL += element.offsetLeft || 0;
      element = element.offsetParent;
    } while (element);

    return [valueL, valueT];
  },

  positionedOffset: function(element) {
    var valueT = 0, valueL = 0;

    do {
      valueT += element.offsetTop  || 0;
      valueL += element.offsetLeft || 0;
      element = element.offsetParent;
      if (element) {
        p = Element.getStyle(element, 'position');
        if (p == 'relative' || p == 'absolute') break;
      }
    } while (element);
    return [valueL, valueT];
  },

  offsetParent: function(element) {
    if (element.offsetParent) return element.offsetParent;
    if (element == document.body) return element;

    while ((element = element.parentNode) && element != document.body)
      if (Element.getStyle(element, 'position') != 'static')
        return element;

    return document.body;
  },

  // caches x/y coordinate pair to use with overlap
  within: function(element, x, y) {
    if (this.includeScrollOffsets)
      return this.withinIncludingScrolloffsets(element, x, y);
    this.xcomp = x;
    this.ycomp = y;
    this.offset = this.cumulativeOffset(element);

    return (y >= this.offset[1] &&
            y <  this.offset[1] + element.offsetHeight &&
            x >= this.offset[0] &&
            x <  this.offset[0] + element.offsetWidth);
  },

  withinIncludingScrolloffsets: function(element, x, y) {

    var offsetcache = this.realOffset(element);

    this.xcomp = x + offsetcache[0] - this.deltaX;
    this.ycomp = y + offsetcache[1] - this.deltaY;
    this.offset = this.cumulativeOffset(element);

    return (this.ycomp >= this.offset[1] &&
            this.ycomp <  this.offset[1] + element.offsetHeight &&
            this.xcomp >= this.offset[0] &&
            this.xcomp <  this.offset[0] + element.offsetWidth);
  },

  // within must be called directly before
  overlap: function(mode, element) {
    if (!mode) return 0;
    if (mode == 'vertical')
      return ((this.offset[1] + element.offsetHeight) - this.ycomp) /
	    element.offsetHeight;
    if (mode == 'horizontal')
      return ((this.offset[0] + element.offsetWidth) - this.xcomp) /
        element.offsetWidth;
  },

  clone: function(source, target) {
    source = $(source);
    target = $(target);
    target.style.position = 'absolute';
    var offsets = this.cumulativeOffset(source);
    target.style.top    = offsets[1] + 'px';
    target.style.left   = offsets[0] + 'px';
    target.style.width  = source.offsetWidth + 'px';
    target.style.height = source.offsetHeight + 'px';
  },

  page: function(forElement) {
    var valueT = 0, valueL = 0;

    var element = forElement;
    do {
      valueT += element.offsetTop  || 0;
      valueL += element.offsetLeft || 0;

      // Safari fix
      if (element.offsetParent==document.body)
        if (Element.getStyle(element,'position')=='absolute') break;

    } while (element = element.offsetParent);

    element = forElement;
    do {
      valueT -= element.scrollTop  || 0;
      valueL -= element.scrollLeft || 0;
    } while (element = element.parentNode);

    return [valueL, valueT];
  },

  clone: function(source, target) {
    var options = Object.extend({
      setLeft:    true,
      setTop:     true,
      setWidth:   true,
      setHeight:  true,
      offsetTop:  0,
      offsetLeft: 0
    }, arguments[2] || {});

    // find page position of source
    source = $(source);
    var p = Position.page(source);

    // find coordinate system to use
    target = $(target);
    var delta = [0, 0];
    var parent = null;
    // delta [0,0] will do fine with position: fixed elements,
    // position:absolute needs offsetParent deltas
    if (Element.getStyle(target,'position') == 'absolute') {
      parent = Position.offsetParent(target);
      delta = Position.page(parent);
    };

    // correct by body offsets (fixes Safari)
    if (parent == document.body) {
      delta[0] -= document.body.offsetLeft;
      delta[1] -= document.body.offsetTop;
    };

    // set position
    if(options.setLeft)   target.style.left  = (p[0] - delta[0] + options.offsetLeft) + 'px';
    if(options.setTop)    target.style.top   = (p[1] - delta[1] + options.offsetTop) + 'px';
    if(options.setWidth)  target.style.width = source.offsetWidth + 'px';
    if(options.setHeight) target.style.height = source.offsetHeight + 'px';
  },

  absolutize: function(element) {
    element = $(element);
    if (element.style.position == 'absolute') return;
    Position.prepare();

    var offsets = Position.positionedOffset(element);
    var top     = offsets[1];
    var left    = offsets[0];
    var width   = element.clientWidth;
    var height  = element.clientHeight;

    element._originalLeft   = left - parseFloat(element.style.left  || 0);
    element._originalTop    = top  - parseFloat(element.style.top || 0);
    element._originalWidth  = element.style.width;
    element._originalHeight = element.style.height;

    element.style.position = 'absolute';
    element.style.top    = top + 'px';;
    element.style.left   = left + 'px';;
    element.style.width  = width + 'px';;
    element.style.height = height + 'px';;
  },

  relativize: function(element) {
    element = $(element);
    if (element.style.position == 'relative') return;
    Position.prepare();

    element.style.position = 'relative';
    var top  = parseFloat(element.style.top  || 0) - (element._originalTop || 0);
    var left = parseFloat(element.style.left || 0) - (element._originalLeft || 0);

    element.style.top    = top + 'px';
    element.style.left   = left + 'px';
    element.style.height = element._originalHeight;
    element.style.width  = element._originalWidth;
  }
};

// Safari returns margins on body which is incorrect if the child is absolutely
// positioned.  For performance reasons, redefine Position.cumulativeOffset for
// KHTML/WebKit only.
if (/Konqueror|Safari|KHTML/.test(navigator.userAgent)) {
  Position.cumulativeOffset = function(element) {
    var valueT = 0, valueL = 0;
    do {
      valueT += element.offsetTop  || 0;
      valueL += element.offsetLeft || 0;
      if (element.offsetParent == document.body)
        if (Element.getStyle(element, 'position') == 'absolute') break;

      element = element.offsetParent;
    } while (element);

    return [valueL, valueT];
  }
};




Object.extend(String.prototype, {
  truncate: function(length, truncation) {
    length = length || 30;
    truncation = truncation === undefined ? '...' : truncation;
    return this.length > length ? this.slice(0, length - truncation.length) + truncation : this;
  },

  strip: function() {
    return this.replace(/^\s+/, '').replace(/\s+$/, '');
  },

  stripTags: function() {
    return this.replace(/<\/?[^>]+>/gi, '');
  }
});





function TabClass(params){
	var p = params.p,c = params.c;
	var i;
	if(!p || !c || p.constructor != Array || c.constructor != Array || p.length == 0 || p.length != c.length){
		alert('���������������ȷ��');
		return false;
	};
	var nodeArr = new Array(p.length);
	for(i = 0; i < p.length; i++){		
		if(typeof p[i] == 'string') p[i] = document.getElementById(p[i]);
		if(typeof c[i] == 'string') c[i] = document.getElementById(c[i]);
		
		nodeArr[i] = new Array();
		this.nodeGroup(p[i],nodeArr[i]);
	};
	//�жϽṹ�Ƿ���ͬ
	var nodeSame = true;
	for(i = 1; i < p.length; i++){
		if(nodeArr[0].length != nodeArr[i].length){
			nodeSame = false;
			break;
		}
	};
	//����ṹ��ͬ�����Ե�һ���ڵ�Ϊ��׼������c1��c2����ʽ���Ը������ڵ�
	if(nodeSame){
		for(i = 1; i < nodeArr.length; i++){
			for(var j = 0; j < nodeArr[i].length; j++){//alert(nodeArr[0][j].getAttribute('c1'))
				if(!nodeArr[i][j].getAttribute('c1') && nodeArr[0][j].getAttribute('c1')) nodeArr[i][j].setAttribute('c1',nodeArr[0][j].getAttribute('c1'));
				if(!nodeArr[i][j].getAttribute('c2') && nodeArr[0][j].getAttribute('c2')) nodeArr[i][j].setAttribute('c2',nodeArr[0][j].getAttribute('c2'));
			};
		};
	};
	var aaa = [];
	for(i = 0; i < p.length; i++){
	//	aaa.push(p[i].outerHTML);
	}
	//alert(aaa.join('\n\n'))
	
	this.p = p;
	this.c = c;
	this.curIndex = 0;
	this.isOver = false;
	var _this = this;
	for(i = 0; i < p.length; i++){
		p[i].setAttribute('_index',i);
		p[i].onmouseover = function(){
			_this.isOver = true;
			_this.change(this.getAttribute('_index'));			
		};
		p[i].onmouseout = function(){
			_this.isOver = false;
		};
	};
	
};

TabClass.prototype = {
	change : function(index){
		var p = this.p,c = this.c;
		for(var i = 0; i < p.length; i++){
			if(i == index){
				this.changeClassName(p[i],1);
				this.c[i].style.display = '';
			}else{
				this.changeClassName(p[i],2);
				this.c[i].style.display = 'none';
			};
		};
	},
	changeClassName : function(obj,flag){
		if(!obj || !obj.tagName) return false;
		if(obj.getAttribute('c' + flag)){
			obj.className = obj.getAttribute('c' + flag);
		}else{			
			if(obj.getAttribute('c1') || obj.getAttribute('c2')){
				obj.removeAttribute('className');
				obj.removeAttribute('class');
			}
		};
		if(obj.hasChildNodes()){
			for(var i = 0; i < obj.childNodes.length; i++){
				this.changeClassName(obj.childNodes[i],flag);
			};
		};
	},
	nodeGroup : function(obj,arr){
		if(!obj || !obj.tagName) return false;
		arr.push(obj);
		if(obj.hasChildNodes()){
			for(var i = 0; i < obj.childNodes.length; i++){
				this.nodeGroup(obj.childNodes[i],arr);
			};
		};
	}
};



document.writeln("<script language=\"javascript\" src=\"/js/Doctor.js\"><\/script>") ;

//����ҽԺ�½��б���
function DoctorData(array,pObj,cObj){
   //���飬����������Դ
	this.array=array; 
	if(typeof pObj == 'object')
   		this.pObj = pObj;
	else
		this.pObj = document.getElementById(pObj);
	if(typeof cObj == 'object')
   		this.cObj = cObj;
	else
		this.cObj = document.getElementById(cObj);
		
	var _this = this;	
	
	this.pObj.onchange = function(){
		if(!_this.cObj) return false;
		var val = this.options[this.selectedIndex].value;
		_this.optionChange(val,_this.cObj);		
	
	}
	
};

DoctorData.prototype = {
	optionChange : function(val,obj){
		obj.length=0;
		obj.options[0]=new Option("��ѡ��",'');
		if(val === '') return false;
		for(var i=0;i<this.array.length;i++){ 	
		 	if(this.array[i][1]== parseInt(val)){
		  		obj.options[obj.length]=new Option(this.array[i][2],this.array[i][0]);
		 	};
		};
	},
	init : function(){
		this.optionChange(0,this.pObj);//��ʼ������
	}
};
//************************************************************************************************************************
//������ѯ
//************************************************************************************************************************
function OnlineAsk(oForm){
	if(typeof oForm == 'object')
   		this.oForm = oForm;
	else
		this.oForm = document.getElementById(oForm);
};
OnlineAsk.prototype = {
	//����
	post : function(obj){
		if(!this.check()) return false;
		obj.setAttribute('disabled',true);
		var oForm = this.oForm;
		var params = {
			"UserName" : oForm.UserName.value,
			"Addr" : oForm.Addr.value,
			"Tel" : oForm.Tel.value,
			"Title" : oForm.Title.value,
			"Content" : oForm.Content.value			
		};
		var url = '/Asp/OnlineAsk.asp';
		new Ajax.Request(url,{method : 'post',postBody : $H(params).toQueryString(),																	 			onSuccess : function(o){				
				try{
					var result = decodeURIComponent(o.responseText).split(',');
					var tStatus = result[0];
					var tMsg = result[1];
					alert(decodeURIComponent(o.responseText));	
					if(Number(tStatus) == 1){
					    alert(tMsg || '�ύ�ɹ�!');							
						oForm.UserName.value = '';
						oForm.Addr.value = '';
						oForm.Tel.value	= ''; 
						oForm.Title.value = '';
						oForm.Content.value = '';
						obj.setAttribute('disabled',false);
					}else{					
						alert(tMsg || '�ύʧ��1!');
						obj.setAttribute('disabled',false);
					};
				}catch(e){
					obj.setAttribute('disabled',false);
					alert('�ύʧ��2!' + e.message);
				}
			},
			onFailure : function(o){
				alert('�ύʧ��3!');	
				obj.setAttribute('disabled',false);			
			},
			onComplete : function(o){
				obj.setAttribute('disabled',false);
			}
		});
	},
		check : function(){
		var oForm = this.oForm;

		if (oForm.UserName.value == ""){
		 	alert("�������������!");
		 	oForm.UserName.focus();
		 	return false;
	   	};
		if (oForm.Addr.value == ""){
		 	alert("��������ĵ�ַ!");
		 	oForm.Addr.focus();
		 	return false;
	   	};
		if (oForm.Tel.value == ""){
		 	alert("�����������ϵ�绰!");
		 	oForm.Tel.focus();
		 	return false;
	   	};
		

		if (oForm.Title.value == ""){
		 	alert("����������!");
		 	oForm.Title.focus();
		 	return false;
	   	};
		if (oForm.Content.value == ""){
		 	alert("����������!");
		 	oForm.Content.focus();
		 	return false;
	   	};
		return true;
	},
	//ȡ����
	getData : function(obj,num,deptId){
		if(typeof obj != 'object') obj = document.getElementById(obj);
		if(!deptId) deptId = 0;
		if(!num) num = 10;	
		var template = obj.innerHTML;
		var params = {"num" : num,"DeptId" : deptId,"t" : template}
		var url = '/Asp/GetOnlineAsk.asp';
		obj.innerHTMl = '���ڶ�ȡ���ݣ����Եȡ�����';
		new Ajax.Request(url,{method : 'post',postBody : $H(params).toQueryString(),
			onSuccess : function(o){				
				try{
					var result = decodeURIComponent(o.responseText);
					obj.innerHTML = result;			
				}catch(e){
					obj.innerHTML = '��ȡ����ʧ�ܣ�';	
				}
			},
			onFailure : function(o){
				obj.innerHTML = '��ȡ����ʧ�ܣ�';		
			}
		});
	}
};

//************************************************************************************************************************
//'����ԤԼ
//************************************************************************************************************************
function OnlineBook(oForm){
	if(typeof oForm == 'object')
   		this.oForm = oForm;
	else
		this.oForm = document.getElementById(oForm);
};
OnlineBook.prototype = {
	post : function(obj){
		if(!this.check()) return false;
		obj.setAttribute('disabled',true);
		var oForm = this.oForm;

		var params = {
			"UserName" : oForm.UserName.value,
			"Addr" : oForm.Addr.value,
			"Tel" : oForm.Tel.value,
			"Disease" : oForm.Disease?oForm.Disease.value : 'δ֪',
			"BookTime" : oForm.BookTime.value, 
			"Content" :  oForm.Content.value 
			
		};
		var url = '/Asp/OnlineBook.asp';
		new Ajax.Request(url,{method : 'post',postBody : $H(params).toQueryString(),
			onSuccess : function(o){				
				try{
					var result = decodeURIComponent(o.responseText).split(',');
					var tStatus = result[0];
					var tMsg = result[1];
					if(Number(tStatus) == 1){
					    alert(tMsg || '�ύ�ɹ�1!');							
						oForm.UserName.value = '';
						oForm.Addr.value = '';
						oForm.Tel.value	= ''; 
						if(oForm.Disease)oForm.Disease.value = ''; 
						oForm.Content.value = '';						
					}else{					
						alert(tMsg || '�ύʧ��2!');
					};
				}catch(e){
					alert('�ύʧ��3!' + e.message);
				}
			},
			onFailure : function(o){
				alert('�ύʧ��4!');				
			},
			onComplete : function(o){
				obj.setAttribute('disabled',false);
			}
		});
	},
		check : function(){
		var oForm = this.oForm;

		if (oForm.UserName.value == ""){
		 	alert("�������������!");
		 	oForm.UserName.focus();
		 	return false;
	   	};
		var xm=  /[\u4E00-\u9FA5]+$/;           
		if(!xm.test(oForm.UserName.value)){
		alert('����д��ȷ��������ʽ');
		oForm.UserName.focus();
		return false;
		};
		var pl= /^([0-9]{11})?$/;
		if(!pl.test(oForm.Tel.value)){
		
		alert('����д��ȷ���ֻ��Ÿ�ʽ');
		oForm.Tel.focus();
		return false;
		};
		if (oForm.Addr.value == ""){
		 	alert("��������ĵ�ַ!");
		 	oForm.Addr.focus();
		 	return false;
	   	};
		if (oForm.Tel.value == ""){
		 	alert("�����������ϵ�绰!");
		 	oForm.Tel.focus();
		 	return false;
	   	};
		if (oForm.Content.value == ""){
		 	alert("����������!");
		 	oForm.Content.focus();
		 	return false;
	   	};
		return true;
	},
//ȡ����
	getData2 : function(obj,num,deptId){
		if(typeof obj != 'object') obj = document.getElementById(obj);
		if(!deptId) deptId = 0;
		if(!num) num = 10;	
		var template = obj.innerHTML;
		var params = {"num" : num,"DeptId" : deptId,"t" : template}
	
		var url = '/Asp/GetBookAsk.asp';
		obj.innerHTMl = '���ڶ�ȡ���ݣ����Եȡ�����';
		new Ajax.Request(url,{method : 'post',postBody : $H(params).toQueryString(),
			onSuccess : function(o){				
				try{
					var result = decodeURIComponent(o.responseText);
					obj.innerHTML = result;			
				}catch(e){
					obj.innerHTML = '��ȡ����ʧ�ܣ�';	
				}
			},
			onFailure : function(o){
				obj.innerHTML = '��ȡ����ʧ�ܣ�';		
			}
		});
	}
}; 

//************************************************************************************************************************
//'����ԤԼ
//************************************************************************************************************************
function OnlineEMail(oForm){
	if(typeof oForm == 'object')
   		this.oForm = oForm;
	else
		this.oForm = document.getElementById(oForm);
};
OnlineEMail.prototype = {
	post : function(obj){
		if(!this.check()) return false;
		obj.setAttribute('disabled',true);
		var oForm = this.oForm;
		var params = {
			"UserName" : oForm.UserName.value,
			"Tel" : oForm.Tel.value,
			"EMail" : oForm.EMail.value,
			"Title" : oForm.Title.value,
			"Content" : oForm.Content.value			
		};
		var url = '/Asp/OnlineEMail.asp';
		new Ajax.Request(url,{method : 'post',postBody : $H(params).toQueryString(),
			onSuccess : function(o){				
				try{
					var result = decodeURIComponent(o.responseText).split(',');
					var tStatus = result[0];
					var tMsg = result[1];
					if(Number(tStatus) == 1){
					    alert(tMsg || '�ύ�ɹ�!');							
						oForm.UserName.value = '';
						oForm.EMail.value = '';
						oForm.Tel.value	= ''; 
						oForm.Title.value = '';
						oForm.Content.value = '';						
					}else{					
						alert(tMsg || '�ύʧ��!');
					};
				}catch(e){
					alert('�ύʧ��!' + e.message);
				}
			},
			onFailure : function(o){
				alert('�ύʧ��!');				
			},
			onComplete : function(o){
				obj.setAttribute('disabled',false);
			}
		});
	},
		check : function(){
		var oForm = this.oForm;

		if (oForm.UserName.value == ""){
		 	alert("�������������!");
		 	oForm.UserName.focus();
		 	return false;
	   	};
		if (oForm.Tel.value == ""){
		 	alert("�����������ϵ�绰!");
		 	oForm.Tel.focus();
		 	return false;
	   	};
		if (oForm.Title.value == ""){
		 	alert("�������������!");
		 	oForm.Title.focus();
		 	return false;
	   	};
		if (oForm.Content.value == ""){
		 	alert("����������!");
		 	oForm.Content.focus();
		 	return false;
	   	};
		return true;
	}
};

//@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
//��ʼ��
//@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
Event.observe(window,'load', function(){
	var oForm = $('BookForm');
	if(oForm){
		Js_bindCalenders(oForm);//����ԤԼ���ڳ�ʼ��
	};
});
    
  
//Baiduվ������
function baidusearch () {
var wd=document.getElementsByName("wd")[0].value;
var link="http://www.baidu.com/s?si=www.trfkyy.com&cl=3&ct=2097152&tn=baidulocal&word="+wd;
window.open(link); }



function swf(src,w,h){
	html = '';
	html += '<object classid="clsid:d27cdb6e-ae6d-11cf-96b8-444553540000" codebase="http://fpdownload.macromedia.com/pub/shockwave/cabs/flash/swflash.cab#version=8,0,0,0" width="'+w+'" height="'+h+'">';
	html += '<param name="allowScriptAccess" value="sameDomain" />';
	html += '<param name="movie" value="'+src+'" />';
	html += '<param name="quality" value="high" />';
	html += '<param name="wmode" value="transparent" />';
	html += '<embed wmode="transparent" src="'+src+'" quality="high" bgcolor="#cc6600" width="'+w+'" height="'+h+'" name="main" align="center" allowScriptAccess="sameDomain" type="application/x-shockwave-flash" pluginspage="http://www.macromedia.com/go/getflashplayer" />';
	html += '<\/object>';
	document.write(html);
};


function swf1(src,w,h,panel){
	var html = '';
	html += '<object classid="clsid:d27cdb6e-ae6d-11cf-96b8-444553540000" codebase="http://fpdownload.macromedia.com/pub/shockwave/cabs/flash/swflash.cab#version=8,0,0,0" width="'+w+'" height="'+h+'">';
	html += '<param name="allowScriptAccess" value="sameDomain" />';
	html += '<param name="movie" value="'+src+'" />';
	html += '<param name="quality" value="high" />';
	html += '<param name="wmode" value="transparent" />';
	html += '<embed wmode="transparent" src="'+src+'" quality="high" bgcolor="#cc6600" width="'+w+'" height="'+h+'" name="main" align="center" allowScriptAccess="sameDomain" type="application/x-shockwave-flash" pluginspage="http://www.macromedia.com/go/getflashplayer" />';
	html += '<\/object>';
	var oPanel = document.getElementById(panel);
	var oDiv = document.createElement('div');
	oDiv.innerHTML = html;
	for(var i = 0; i < oDiv.childNodes.length; i++){
		oPanel.appendChild(oDiv.childNodes[i]);
	};
	oDiv = null;
}


function showFlashNews(img,link,text,params){
	if(!img.replace(/\s*/gi,'')) return false;
	
	params = params?params : {};
	var pic_width= params.w?params.w : 340; //ͼƬ����
	var pic_height= params.h?params.h : 275; //ͼƬ�߶�
	var button_pos= params.p?params.p : 4; //��Ťλ�� 1�� 2�� 3�� 4��
	var stop_time= params.t?params.t : 8000; //ͼƬͣ��ʱ��(1000Ϊ1����)
	var show_text =params.showText?params.showText : 0; //�Ƿ���ʾ���ֱ�ǩ 1��ʾ 0����ʾ
	var txtcolor="000000"; //����ɫ
	var bgcolor="FFFFFF"; //����ɫ
	
	
	
	//�ɱ༭���ݽ���
	var swf_height=show_text==1?pic_height+20:pic_height;
	var pics=img.replace(/,/gi,'|'), links=link?link.replace(/,/gi,'|') : '', texts=text?text.replace(/,/gi,'|') : '';
	
	

	document.write('<object classid="clsid:d27cdb6e-ae6d-11cf-96b8-444553540000" codebase="http://fpdownload.macromedia.com/pub/shockwave/cabs/flash/swflash.cabversion=6,0,0,0" width="'+ pic_width +'" height="'+ swf_height +'">');
	document.write('<param name="movie" value="/flash/focus.swf">');
	document.write('<param name="quality" value="high"><param name="wmode" value="opaque">');
	document.write('<param name="FlashVars" value="pics='+pics+'&links='+links+'&texts='+texts+'&pic_width='+pic_width+'&pic_height='+pic_height+'&show_text='+show_text+'&txtcolor='+txtcolor+'&bgcolor='+bgcolor+'&button_pos='+button_pos+'&stop_time='+stop_time+'">');
	document.write('<embed src="/flash/focus.swf" FlashVars="pics='+pics+'&links='+links+'&texts='+texts+'&pic_width='+pic_width+'&pic_height='+pic_height+'&show_text='+show_text+'&txtcolor='+txtcolor+'&bgcolor='+bgcolor+'&button_pos='+button_pos+'&stop_time='+stop_time+'" quality="high" width="'+ pic_width +'" height="'+ swf_height +'" allowScriptAccess="sameDomain" type="application/x-shockwave-flash" pluginspage="http://www.macromedia.com/go/getflashplayer" />');
	document.write('</object>');



	//var html = '<object classid="clsid:d27cdb6e-ae6d-11cf-96b8-444553540000" codebase="http://fpdownload.macromedia.com/pub/shockwave/cabs/flash/swflash.cabversion=6,0,0,0" width="'+ pic_width +'" height="'+ swf_height +'">';
	//html += '<param name="movie" value="/flash/focus.swf">';
	//html += '<param name="quality" value="high"><param name="wmode" value="opaque">';
	//html += '<param name="FlashVars" value="pics='+pics+'&links='+links+'&texts='+texts+'&pic_width='+pic_width+'&pic_height='+pic_height+'&show_text='+show_text+'&txtcolor='+txtcolor+'&bgcolor='+bgcolor+'&button_pos='+button_pos+'&stop_time='+stop_time+'">';
	//html += '<embed src="/flash/focus.swf" FlashVars="pics='+pics+'&links='+links+'&texts='+texts+'&pic_width='+pic_width+'&pic_height='+pic_height+'&show_text='+show_text+'&txtcolor='+txtcolor+'&bgcolor='+bgcolor+'&button_pos='+button_pos+'&stop_time='+stop_time+'" quality="high" width="'+ pic_width +'" height="'+ swf_height +'" allowScriptAccess="sameDomain" type="application/x-shockwave-flash" pluginspage="http://www.macromedia.com/go/getflashplayer" />';
	//html += '</object>';
	//if(params.panel){
	//	if(typeof params.panel == 'string') params.panel = document.getElementById(params.panel);
	//	params.panel.innerHTML = html;
	//}else{
	//	document.write(html);
	//};
}

function changeTelImg(){
	if(document.domain.indexOf("23462210.com")>0 || document.domain.indexOf("27909999.com")>0){
		//document.body.style.backgroundImage="url(/images/newIndex/page_bg_01.jpg)";
		document.getElementById('tupian').src="/images/newIndex/trfkyy_new2013_03_01.png";
		document.getElementById('aabc').alt="/images/newIndex/banner2013-02_01.jpg";
	}else
	{
		document.getElementById('tupian').src="/images/newIndex/trfkyy_new2013_03.png";
		document.getElementById('aabc').alt="/images/newIndex/banner2013-02.jpg";
		}

	
}

//changeTelImg();


// JavaScript Document
function correctPNG() // correctly handle PNG transparency in Win IE 5.5 & 6. 
{ 
    var arVersion = navigator.appVersion.split("MSIE") 
    var version = parseFloat(arVersion[1]) 
    if ((version >= 5.5) && (document.body.filters)) 
    { 
       for(var j=0; j<document.images.length; j++) 
       { 
          var img = document.images[j] 
          var imgName = img.src.toUpperCase() 
          if (imgName.substring(imgName.length-3, imgName.length) == "PNG") 
          { 
             var imgID = (img.id) ? "id='" + img.id + "' " : "" 
             var imgClass = (img.className) ? "class='" + img.className + "' " : "" 
             var imgTitle = (img.title) ? "title='" + img.title + "' " : "title='" + img.alt + "' " 
             var imgStyle = "display:inline-block;" + img.style.cssText 
             if (img.align == "left") imgStyle = "float:left;" + imgStyle 
             if (img.align == "right") imgStyle = "float:right;" + imgStyle 
             if (img.parentElement.href) imgStyle = "cursor:hand;" + imgStyle 
             var strNewHTML = "<span " + imgID + imgClass + imgTitle 
             + " style=\"" + "width:" + img.width + "px; height:" + img.height + "px;" + imgStyle + ";" 
             + "filter:progid:DXImageTransform.Microsoft.AlphaImageLoader" 
             + "(src=\'" + img.src + "\', sizingMethod='scale');\"></span>" 
             img.outerHTML = strNewHTML 
             j = j-1 
          } 
       } 
    }     
} 
window.attachEvent("onload", correctPNG);
document.writeln("<script language=\"javascript\" src=\"/js/prototype.js\"></script>");
document.writeln("<script language=\"javascript\" src=\"/js/Calendar.js\"></script>");

